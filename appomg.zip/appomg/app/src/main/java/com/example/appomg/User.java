package com.example.appomg;

public class User {

    private String name;
    private String email;
    private String phone_number;
    private String card;
    private String password;
    private String id;
    private String username;
    private String imageURL;
    private String status;
    private String search;
    private String imgUrl;

    public User() {


    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone_num() {
        return phone_number;
    }

    public void setPhone_num(String phone_num) {
        this.phone_number = phone_num;
    }
    public String getCard() {
        return card;
    }

    public void setCard(String card) {
        this.card = card;
    }


    public void setPassword(String password) {
        this.password = password;
    }  public String getPassword() {
        return password;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }

}
