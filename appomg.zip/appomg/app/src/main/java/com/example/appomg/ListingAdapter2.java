package com.example.appomg;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.storage.FirebaseStorage;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class ListingAdapter2 extends RecyclerView.Adapter<ListingAdapter2.ImageViewHolder> {
    private Context mContext;
    private FirebaseStorage mStorage;
    private List<Order> mUploads;
    private OnItemClickListener mListener;
    View view;
public static final String user_key="User_key";
    public ListingAdapter2(Context context, List<Order> orders)
    {
        this.mContext=context;
        this.mUploads=orders;
    }



    @NonNull
    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v= LayoutInflater.from(mContext).inflate(R.layout.userupload_item, viewGroup,false);
        return  new ImageViewHolder(v);
    }


    @Override
    public void onBindViewHolder(@NonNull ImageViewHolder imageViewHolder, int i) {
        /*final Upload uploadCur = mUploads.get(i);*/
           final Order order=mUploads.get(i);
        imageViewHolder.img_description.setText("物品名稱:"+order.getName());
        Picasso.with(mContext)
                .load(order.getImgUrl())
                .placeholder(R.drawable.imagepreview)
                .fit()
                .centerCrop()
                .into(imageViewHolder.image_view);

        imageViewHolder.place.setText("地區:"+order.getPlace());
        imageViewHolder.price.setText("一次價錢:$"+order.getPrice());
        imageViewHolder.day.setText("租用日期:"+order.getDay());  //刊登日期


        imageViewHolder.image_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String key =order.getKey();
                Intent intent=new Intent(mContext,list_ing_detail2.class);
                intent.putExtra(user_key,key);
                mContext.startActivity(intent);

            }
        });

    }


    @Override
    public int getItemCount() {
        return mUploads.size();
    }

    public void filteredList(ArrayList<Order> myUploads) {
        mUploads=myUploads;
        notifyDataSetChanged();
    }





    public class ImageViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener,
    View.OnCreateContextMenuListener, MenuItem.OnMenuItemClickListener {
        public TextView img_description,place,price,day;
        public ImageView image_view;

        public ImageViewHolder(@NonNull View itemView) {
            super(itemView);
            img_description=itemView.findViewById(R.id.img_description);
            image_view=itemView.findViewById(R.id.imgurl);
            place=itemView.findViewById(R.id.place);
            price=itemView.findViewById(R.id.price);
            day=itemView.findViewById(R.id.date);



            itemView.setOnClickListener(this);
            itemView.setOnCreateContextMenuListener(this);
        }

        @Override
        public boolean onMenuItemClick(MenuItem item) {
            if (mListener != null) {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {

                    switch (item.getItemId()) {
                        case 1:
                            mListener.onWhatEverClick(itemView);
                            return true;
                        case 2:
                            mListener.onDeleteClick(position);
                            return true;
                    }
                }
            }
            return false;
        }


        @Override
        public void onClick(View v) {
            if (mListener != null) {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    mListener.onItemClick(position);
                }
            }
        }

        @Override
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
            menu.setHeaderTitle("Select Action");
            MenuItem doWhatever = menu.add(Menu.NONE, 1, 1, "Do whatever");
            MenuItem delete = menu.add(Menu.NONE, 2, 2, "Delete");

            doWhatever.setOnMenuItemClickListener(this);
            delete.setOnMenuItemClickListener(this);
        }
    }
    public interface OnItemClickListener {
        void onItemClick(int position);

        void onWhatEverClick(View view);

        void onDeleteClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }


}
