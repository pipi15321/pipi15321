package com.example.appomg;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class list_wait extends AppCompatActivity implements  ListwaitAdapter.OnItemClickListener{
    private static final String TAG = "Main2Activity";
    private ChildEventListener mchildListener;
    private ValueEventListener mDBListener;
    private RecyclerView mRecyclerView;
    private ProgressBar progressBar;
    private DatabaseReference mDatabaseRef;
    private List<Order> mUploads;

    private  ListwaitAdapter mAdapter;
    private Context mContext;
    private FirebaseStorage mStorage;
    FirebaseRecyclerAdapter<Upload, RecyclerView.ViewHolder> adapter;
    private SearchView searchView;
    private ViewPager mViewPager;
    private String userUID;
    FirebaseAuth auth;
    private EditText edit;
    FirebaseAuth.AuthStateListener authListener;
    private int position;
    int counter = 0;
    View view;
    private Button rent,borrow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_wait);

        auth = FirebaseAuth.getInstance();
        progressBar = findViewById(R.id.progress_circular);
        /*   uidtext = findViewById(R.id.uidtext);*/
        mRecyclerView = findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        edit = findViewById(R.id.edit);

        mStorage = FirebaseStorage.getInstance();
        mUploads = new ArrayList<>();

        rent = findViewById(R.id.rent);
        borrow = findViewById(R.id.borrow);

        mDatabaseRef = FirebaseDatabase.getInstance().getReference("order");

        edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });


        mDBListener = mDatabaseRef.addValueEventListener(new ValueEventListener() {


            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                mUploads.clear();

                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Order order= postSnapshot.getValue(Order.class);
                    order.setKey(postSnapshot.getKey());
                    mUploads.add(order);

                }
                mAdapter = new ListwaitAdapter(list_wait.this, mUploads);
                mRecyclerView.setAdapter(mAdapter);
                mAdapter.setOnItemClickListener(list_wait.this);
                mAdapter.notifyDataSetChanged();

                progressBar.setVisibility(View.INVISIBLE);
            }
            /* progressBar.setVisibility(View.INVISIBLE);*/


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(list_wait.this, databaseError.getMessage(), Toast.LENGTH_LONG).show();
                progressBar.setVisibility(View.INVISIBLE);

            }
        });
     rent(view);


    }

    @Override
    public void onItemClick(int position) {

        Toast.makeText(this, "Normal click at position: " + position, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onWhatEverClick(View view) {

        Toast.makeText(this, "Whatever click at position: " + position, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDeleteClick(int position) {
       Order selectedItem = mUploads.get(position);
        final String selectedKey = selectedItem.getKey();
        StorageReference imageRef = mStorage.getReferenceFromUrl(selectedItem.getImgUrl());
        imageRef.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                mDatabaseRef.child(selectedKey).removeValue();
                Toast.makeText(list_wait.this, "Item deleted", Toast.LENGTH_SHORT).show();
                mUploads.clear();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mDatabaseRef.removeEventListener(mDBListener);
    }


    private void filter(String text) {
        ArrayList<Order> myUploads = new ArrayList<>();
        for (Order item : mUploads) {
            if (item.getName().toLowerCase().contains(text.toLowerCase())) {
                myUploads.add(item);
            }

        }
        mAdapter.filteredList(myUploads);
        mRecyclerView.setAdapter(mAdapter);
    }

    public void re(View view) {
        Intent intent = new Intent();
        intent.setClass(list_wait.this, ActivityTwo.class);
        startActivity(intent);
    }



  public void rent(View view) {
      Query query = FirebaseDatabase.getInstance().getReference().child("order").orderByChild("uid").equalTo(auth.getCurrentUser().getUid());
      query.addListenerForSingleValueEvent(mDBListener);
      rent.setEnabled(false);
      borrow.setEnabled(true);


  }
    public void borrow(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("order").orderByChild("host").equalTo(auth.getCurrentUser().getUid());
        query.addListenerForSingleValueEvent(mDBListener);
        rent.setEnabled(true);
        borrow.setEnabled(false);

    }


    }