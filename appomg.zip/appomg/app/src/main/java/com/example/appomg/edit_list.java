package com.example.appomg;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.List;

import static com.example.appomg.ImageAdapter.user_key;

public class edit_list extends AppCompatActivity implements UseruploadAdapter.OnItemClickListener {
    private TextView name, price, place, day, imgurl2, uid,textView22,type_tv;
    private EditText edit_name, edit_price, edit_place, edit_day,remark,type_et;
    private static final int REQUEST_CODE = 1;
    private ImageView imgurl;
    FirebaseAuth auth;
    Upload upload;
    private ImageButton re;
    private Button  edit, delete;
    DatabaseReference ref, ref1;
    private List<Upload> mUploads;
    private Context mContext;
    private FirebaseStorage mStorage;
    private ValueEventListener mDBListener;
    private int position;
    private Button finish,cnacel_bt;
    private Spinner type,type_sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_list);
        type_sp= findViewById(R.id.type_sp);
        type_tv= findViewById(R.id.type_tv);
        type_et= findViewById(R.id.type_et);
        name = findViewById(R.id.name);
        delete = findViewById(R.id.delete);
        price = findViewById(R.id.price);
        place = findViewById(R.id.place);
        day = findViewById(R.id.date);
        imgurl = findViewById(R.id.imgurl);
        type = findViewById(R.id.type);
        auth = FirebaseAuth.getInstance();
        edit_name = findViewById(R.id.edit_name);
        edit_price = findViewById(R.id.edit_price);
        edit_place = findViewById(R.id.edit_place);
        edit_day = findViewById(R.id.edit_day);
        finish = findViewById(R.id.finish);
        remark = findViewById(R.id.remark);
     textView22 = findViewById(R.id. textView22 );
        cnacel_bt=findViewById(R.id.cancel_bt);
       upload=new Upload();
        final String Key = getIntent().getStringExtra(user_key);
        final DatabaseReference ref = FirebaseDatabase.getInstance().getReference("uploads").child(Key);
        uid = findViewById(R.id.status);
        /*edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit_name.setEnabled(true);
                edit_place.setEnabled(true);
               edit_price.setEnabled(true);
                edit_day.setEnabled(true);

            }
        });*/

        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ref.child("imgName").setValue(edit_name.getText().toString());
                ref.child("price").setValue(edit_price.getText().toString());
                ref.child("place").setValue(type.getSelectedItem().toString());
               /* ref.child("day").setValue(edit_day.getText().toString());*/
                ref.child("remark").setValue(remark.getText().toString());
                ref.child("type").setValue(type_sp.getSelectedItem().toString());
                edit_name.setEnabled(false);
                edit_place.setEnabled(false);
                edit_price.setEnabled(false);
                /*edit_day.setEnabled(false);*/
               remark.setEnabled(false);
                edit_place.setVisibility(View.VISIBLE);
                type_tv.setVisibility(View.VISIBLE);
                type.setVisibility(View.INVISIBLE);
                type_et.setVisibility(View.VISIBLE);
                type_sp.setVisibility(View.INVISIBLE);
                cnacel_bt.setVisibility(View.INVISIBLE);
                finish.setVisibility(View.INVISIBLE);
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ref.child("uid").setValue( textView22 .getText().toString());
                ref.child("state").setValue( textView22 .getText().toString());
                Toast.makeText(edit_list.this, "刪除成功", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(edit_list.this, publish.class);
                startActivity(intent);

            }
        });
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Upload upload = dataSnapshot.getValue(Upload.class);

                Picasso.with(mContext)
                        .load(upload.getImgUrl())
                        .into(imgurl);
                name.setText("物品名稱:");
                edit_name.setText(upload.getImgName());
                place.setText("地區:");
                edit_place.setText(upload.getPlace());
                price.setText("一次價錢:$");
                edit_price.setText(upload.getPrice());
                day.setText("可租用天數:");
                /*edit_day.setText(upload.getDate_start()+"至"+upload.getDate_end());*/
                uid.setText(upload.getUid());
                remark.setText(upload.getRemark());
                type_et.setText(upload.getType());

            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    @Override
    public void onItemClick(int position) {

        Toast.makeText(this, "Normal click at position: " + position, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onWhatEverClick(View view) {

        Toast.makeText(this, "Whatever click at position: " + position, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDeleteClick(int position) {
        Upload selectedItem = mUploads.get(position);
        final String selectedKey = selectedItem.getKey();
        StorageReference imageRef = mStorage.getReferenceFromUrl(selectedItem.getImgUrl());
        imageRef.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                ref.child(selectedKey).removeValue();
                Toast.makeText(edit_list.this, "Item deleted", Toast.LENGTH_SHORT).show();
                mUploads.clear();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ref.removeEventListener(mDBListener);
    }


    public void re(View view) {
        Intent intent = new Intent();
        intent.setClass(edit_list.this, publish.class);
        startActivity(intent);
    }

    public void edit_list(View view) {
        edit_name.setEnabled(true);
       edit_place.setEnabled(true);
        edit_price.setEnabled(true);
       /* edit_day.setEnabled(true);*/
        remark.setEnabled(true);

        /*type_et.setEnabled(true);*/

        edit_place.setVisibility(View.GONE);
        type_et.setVisibility(View.GONE);
        type_sp.setVisibility(View.VISIBLE);
        type.setVisibility(View.VISIBLE);
        cnacel_bt.setVisibility(View.VISIBLE);
        finish.setVisibility(View.VISIBLE);

    }

    public void cancel(View view) {
        edit_name.setEnabled(false);
        edit_place.setEnabled(false);
        edit_price.setEnabled(false);
        edit_day.setEnabled(false);
        remark.setEnabled(false);
        edit_place.setVisibility(View.VISIBLE);

        type.setVisibility(View.INVISIBLE);

        type_et.setVisibility(View.VISIBLE);
        type_sp.setVisibility(View.INVISIBLE);
        cnacel_bt.setVisibility(View.INVISIBLE);
        finish.setVisibility(View.INVISIBLE);


    }



}