package com.example.appomg;

import com.google.firebase.database.Exclude;

public class Order {
    private String imgName;
    private String imgUrl;
    private String name;
    private String uid;
    private String price;
    private String day;
    private String place;
    private String type;
    private String list_type;
    private String state;
    private String date_start;
    private String date_end;
    private String  host;
    private String mKey;
    private String renter;
    private String borrower;
    private String borrower_comment;
    private String renter_comment;
    private String remark;
    private String time;
    private String renter_star;
    private String borrower_star;

    private String username;
    private String host_name;
    private String imageURL;
    private String double_price;

    public String getImgName() {
        return imgName;
    }

    public void setImgName(String imgName) {
        this.imgName = imgName;
    }

    public String getImgUrl() {
        return imgUrl;
    }
    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }


    public void setPlace(String place) {
        this.place = place;
    }  public String getPlace() {
    return place;
}

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getDate_start() {
        return date_start;
    }

    public void setDate_start(String date_start) {
        this.date_start = date_start;
    }

    public String getDate_end() {
        return date_end;
    }

    public void setDate_end(String date_end) {
        this.date_end = date_end;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getHost() {
        return host;
    }

    @Exclude
    public String getKey() {
        return mKey;
    }

    @Exclude
    public void setKey(String key) {
        mKey = key;
    }

    public void setRenter(String renter) {
        this.renter = renter;
    }

    public String getRenter() {
        return renter;
    }

    public void setBorrower(String borrower) {
        this.borrower = borrower;
    }

    public String getBorrower() {
        return borrower;
    }

    public void setBorrower_comment(String borrower_comment) {
        this.borrower_comment = borrower_comment;
    }

    public String getBorrower_comment() {
        return borrower_comment;
    }

    public void setRenter_comment(String renter_comment) {
        this.renter_comment = renter_comment;
    }

    public String getRenter_comment() {
        return renter_comment;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }


    public String getRenter_star() {
        return renter_star;
    }

    public void setRenter_star(String renter_star) {
        this.renter_star = renter_star;
    }

    public String getBorrower_star() {
        return borrower_star;
    }

    public void setBorrower_star(String borrower_star) {
        this.borrower_star= borrower_star;
    }
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }


    public String getDouble_price() {
        return double_price;
    }

    public void setDouble_price(String double_price) {
        this.double_price = double_price;
    }

    public String getHost_name() {
        return host_name;
    }

    public void setHost_name(String host_name) {
        this.host_name = host_name;
    }

}



