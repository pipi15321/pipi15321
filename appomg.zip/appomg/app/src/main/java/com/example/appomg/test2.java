package com.example.appomg;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class test2 extends AppCompatActivity {
    private RecyclerView mRecyclerView,mRecyclerView2;
    View view;
    User user;
    private ValueEventListener mDBListener,mDBListener2;
    private DatabaseReference mDatabaseRef,ref,mDatabaseRef1;
    private List<Order> mUploads;
    private List<Order_wish> mUploads2;
    private User_info_Adapter mAdapter;
    private User_info_Adapter2 mAdapter2;
    private Context mContext;
    private FirebaseStorage mStorage;
    FirebaseRecyclerAdapter<Order, RecyclerView.ViewHolder> adapter;

    FirebaseAuth auth;
    FirebaseAuth.AuthStateListener authListener;
    private int position;
    private CircleImageView  imgPreview;
    private TextView username,host,mTotal,mTotal2;
    private StorageReference mStorageRef;
    private Button renter,borrower;
    private ImageButton re;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test2);
        user = new User();
        auth = FirebaseAuth.getInstance();
        mRecyclerView = findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mRecyclerView2 = findViewById(R.id.recycler_view2);
        mRecyclerView2.setHasFixedSize(true);
        mRecyclerView2.setLayoutManager(new LinearLayoutManager(this));

        renter= findViewById(R.id.renter);
        borrower= findViewById(R.id.borrower);

        mStorage = FirebaseStorage.getInstance();
        mUploads = new ArrayList<>();
        mUploads2 = new ArrayList<>();
        /* mDatabaseRef = FirebaseDatabase.getInstance().getReference("order");*/
        imgPreview = findViewById(R.id.imgPreview);
        username = findViewById(R.id.username);
        host = findViewById(R.id.host);
        String text4 = getIntent().getStringExtra("host");
        host.setText(text4);
        mTotal = findViewById(R.id.mTotal);
        mTotal2 = findViewById(R.id.mTotal2);
        mStorageRef = FirebaseStorage.getInstance().getReference("users");
        mDatabaseRef = FirebaseDatabase.getInstance().getReference("borrower_comment");
        mDatabaseRef1 = FirebaseDatabase.getInstance().getReference("renter_comment");
        ref = FirebaseDatabase.getInstance().getReference().child("Users").child(host.getText().toString());
re=findViewById(R.id.re);
       re.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                User user = dataSnapshot.getValue(User.class);

                if (user.getImageURL().equals("default")){
                    imgPreview.setImageResource(R.drawable.cyclops);
                } else {
                    Picasso.with(mContext)
                            .load(user.getImageURL())
                            .into(imgPreview);

                }
                username.setText(user.getUsername());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        borrower.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                findViewById(R.id.recycler_view2).setVisibility(View.GONE);
                findViewById(R.id.recycler_view).setVisibility(View.VISIBLE);
                findViewById(R.id.a).setVisibility(View.VISIBLE);
                findViewById(R.id.b).setVisibility(View.GONE);
                mDBListener = mDatabaseRef.addValueEventListener(new ValueEventListener() {

                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        int sum = 0;
                        int key = 0;
                        mUploads.clear();
                        for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {


                            Order order = postSnapshot.getValue(Order.class);
                            mUploads.add(order);
                             order.setKey(postSnapshot.getKey());

                            Map<String, Object> map = (Map<String, Object>) postSnapshot.getValue();
                            Object borrower_star = map.get("borrower_star");
                            int pValue = Integer.parseInt(String.valueOf(borrower_star));
                            key++;
                            sum += pValue;


                        }
                        mAdapter = new User_info_Adapter(test2.this, mUploads);
                        mRecyclerView.setAdapter(mAdapter);
                        mAdapter.notifyDataSetChanged();
                        mTotal.setText(String.valueOf((float) sum / key));

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(test2.this, databaseError.getMessage(), Toast.LENGTH_LONG).show();

                    }

                });
                one(view);
            }
        });


                renter.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                findViewById(R.id.recycler_view).setVisibility(View.GONE);
                findViewById(R.id.recycler_view2).setVisibility(View.VISIBLE);
                findViewById(R.id.b).setVisibility(View.VISIBLE);
                findViewById(R.id.a).setVisibility(View.GONE);
                mDBListener2= mDatabaseRef1.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        int sum = 0;
                        int key=0;
                        mUploads2.clear();
                        for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                            Order_wish order = postSnapshot.getValue(Order_wish.class);

                            mUploads2.add(order);
                            order.setKey(postSnapshot.getKey());
                            Map<String, Object> map = (Map<String, Object>) postSnapshot.getValue();
                            Object renter_star = map.get("renter_star");
                            int pValue = Integer.parseInt(String.valueOf(renter_star));
                            key++;
                            sum += pValue;
                        }
                        mAdapter2 = new User_info_Adapter2(test2.this, mUploads2);
                        mRecyclerView2.setAdapter(mAdapter2);
                        mAdapter2.notifyDataSetChanged();
                        mTotal2.setText(String.valueOf((float) sum/key));
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(test2.this, databaseError.getMessage(), Toast.LENGTH_LONG).show();

                    }


                });
                two(view);
            }
        });


    /*mDBListener =mDatabaseRef.addValueEventListener(new ValueEventListener() {
        @Override
        public void onDataChange (@NonNull DataSnapshot dataSnapshot){
           int sum=0;

            for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
              Order order = postSnapshot.getValue(Order.class);
                order.setKey(postSnapshot.getKey());
                mUploads.add(order);
              Map<String,Object> map=(Map<String,Object>) postSnapshot.getValue();
              int pValue=Integer.parseInt(String.valueOf((int)borrower_star));
              sum+=pValue;

            }
            mAdapter = new User_info_Adapter(test2.this, mUploads);
            mRecyclerView.setAdapter(mAdapter);
            mAdapter.notifyDataSetChanged();
           mTotal.setText(String.valueOf(sum));
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {
            Toast.makeText(test2.this, databaseError.getMessage(), Toast.LENGTH_LONG).show();

        }


    });*/

       /* mDatabaseRef1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int sum = 0;
                int key=0;
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Order order = postSnapshot.getValue(Order.class);
                    order.setKey(postSnapshot.getKey());
                    mUploads.add(order);
                    Map<String, Object> map = (Map<String, Object>) postSnapshot.getValue();
                    Object borrower_star = map.get("renter_star");
                    int pValue = Integer.parseInt(String.valueOf(borrower_star));
                    key++;
                    sum += pValue;
                }
                mAdapter = new User_info_Adapter(test2.this, mUploads);
                mRecyclerView2.setAdapter(mAdapter);
                mAdapter.notifyDataSetChanged();
                mTotal.setText(String.valueOf((float) sum/key));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(test2.this, databaseError.getMessage(), Toast.LENGTH_LONG).show();

            }


        });*/
}
    public void one(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("borrower_comment").orderByChild("borrower_uid").equalTo(host.getText().toString());
        query.addListenerForSingleValueEvent(mDBListener);
    }
    public void two(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("renter_comment").orderByChild("renter_uid").equalTo(host.getText().toString());
        query.addListenerForSingleValueEvent(mDBListener2);
    }

}
