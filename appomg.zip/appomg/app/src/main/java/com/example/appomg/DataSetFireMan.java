package com.example.appomg;

public class DataSetFireMan {
    String name;
    String account;
    String email;
    String managertype;
    String password;
    String pswagain;
    String phone;

    public DataSetFireMan() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getManagertype() {
        return managertype;
    }

    public void setManagertype(String managertype) {
        this.managertype = managertype;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPswagain() {
        return pswagain;
    }

    public void setPswagain(String pswagain) {
        this.pswagain = pswagain;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public DataSetFireMan(String name, String account, String email, String managertype, String password, String pswagain, String phone) {
        this.name = name;
        this.account = account;
        this.email = email;
        this.managertype = managertype;
        this.password = password;
        this.pswagain = pswagain;
        this.phone = phone;
    }
}
