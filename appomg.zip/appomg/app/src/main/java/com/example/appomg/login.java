package com.example.appomg;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class login extends AppCompatActivity {
    private static final int RC_SIGN_IN = 1;
    FirebaseAuth auth;
    FirebaseAuth.AuthStateListener authListener;
    private String userUID;
    private static final String TAG = "login";
    EditText email, password;
    UploadMan uploadMan;
    static final int GOOGLE_SIGN_IN = 123;
    FirebaseAuth mAuth;
    Button google, logout;
    GoogleSignInClient mGoogleSignInClient;
    /*private String TAG = "logon";*/
    DatabaseReference ref,ref2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        auth = FirebaseAuth.getInstance();
        email = findViewById(R.id.email);
        google = findViewById(R.id.google);
        password = findViewById(R.id.password);
        uploadMan = new UploadMan();

    authListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(
                    @NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    Log.d("onAuthStateChanged", "登入:" +
                            user.getUid());
                    userUID = user.getUid();
                } else {

                    Log.d("onAuthStateChanged", "已登出");
                }
            }
        };
        ref = FirebaseDatabase.getInstance().getReference().child("UploadMan").child("pp");
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        google.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
signIn();

            }
        });
    }

    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);


    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                // Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = task.getResult(ApiException.class);
                firebaseAuthWithGoogle(account);
            } catch (ApiException e) {
                // Google Sign In failed, update UI appropriately
                Log.w(TAG, "Google sign in failed", e);


                }
                // ...
            }
        }


    private void firebaseAuthWithGoogle(GoogleSignInAccount acct) {
        AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(), null);
        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information

                            Intent intent = new Intent();
                            intent.setClass(login.this,home.class);
                            startActivity(intent);
                            FirebaseUser user1 = auth.getCurrentUser();
                            updateUI(user1);
                        } else {
                            // If sign in fails, display a message to the user.

                            updateUI(null);
                        }

                        // ...
                    }
                });
    }

    private void updateUI(FirebaseUser user) {
        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(getApplicationContext());
        if (acct != null) {
            String presonName = acct.getDisplayName();
            String personGivenName = acct.getGivenName();
            String personFamilyName = acct.getFamilyName();
            String personEmail = acct.getEmail();
            String personId = acct.getId();
            Uri personPhoto = acct.getPhotoUrl();
        }
        Toast.makeText(this, "歡迎來到顧人願", Toast.LENGTH_LONG).show();
    }


    @Override
    protected void onStart() {
        super.onStart();
        auth.addAuthStateListener(authListener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        auth.removeAuthStateListener(authListener);
    }public void login(View v){
        final String email = ((EditText)findViewById(R.id.email))
                .getText().toString();
        final String password = ((EditText)findViewById(R.id.password))
                .getText().toString();

        if("admin".equals(email) &&"admin".equals(password)){
            Intent intent = new Intent(login.this,First.class);
            startActivity(intent);
        }
        if (email.isEmpty()||password.isEmpty()){
            Toast.makeText(login.this, "請輸入帳號密碼", Toast.LENGTH_LONG).show();
        }
        else {
            Log.d("AUTH", email + "/" + password);
            auth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {

                                if (auth.getCurrentUser().isEmailVerified()) {

                                    Intent intent = new Intent(login.this, home.class);
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(login.this, "請至信箱完成驗證", Toast.LENGTH_LONG).show();

                                }
                            } else {
                                Log.d("onComplete", "登入失敗");
                                register(email, password);
                            }

                        }
                    });
        }
    }private void register(final String email, final String password) {
        new AlertDialog.Builder(login.this)
                .setTitle("登入失敗")
                .setMessage("您輸入的帳號或密碼錯誤")
                .setPositiveButton("註冊",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intent = new Intent(login.this,registered.class);
                                startActivity(intent);

                            }
                        })
                .setNegativeButton("忘記密碼",new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(login.this,forgetpassword.class);
                        startActivity(intent);

                    }
                })
                .setNeutralButton("取消", null)
                .show();

    }
    public void registered (View view) {
        Intent intent = new Intent();
        intent.setClass(login.this,RegisterActivity.class);
        startActivity(intent);
    }
    public void forget_password(View view){
        Intent intent = new Intent();
        intent.setClass(login.this,forgetpassword.class);
        startActivity(intent);
    }
    public void back(View view){
        Intent intent = new Intent();
        intent.setClass(login.this, Main2Activity.class);
        startActivity(intent);

    }
}