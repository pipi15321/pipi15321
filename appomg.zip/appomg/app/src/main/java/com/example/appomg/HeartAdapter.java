package com.example.appomg;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.storage.FirebaseStorage;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class HeartAdapter extends RecyclerView.Adapter<HeartAdapter.ImageViewHolder> {
    private Context mContext;
    private FirebaseStorage mStorage;
    private List<Upload> mUploads;
    private OnItemClickListener mListener;
    View view;
public static final String user_key="User_key";
    public HeartAdapter(Context context, List<Upload> uploads)
    {
        this.mContext=context;
        this.mUploads=uploads;
    }



    @NonNull
    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v= LayoutInflater.from(mContext).inflate(R.layout.image_item, viewGroup,false);
        return  new ImageViewHolder(v);
    }


    @Override
    public void onBindViewHolder(@NonNull ImageViewHolder imageViewHolder, int i) {
        /*final Upload uploadCur = mUploads.get(i);*/
           final Upload upload=mUploads.get(i);
        imageViewHolder.img_description.setText(upload.getImgName());
        Picasso.with(mContext)
                .load(upload.getImgUrl())
                .placeholder(R.drawable.imagepreview)
                .fit()
                .centerCrop()
                .into(imageViewHolder.image_view);

        imageViewHolder.place.setText(upload.getPlace());
        imageViewHolder.price.setText(upload.getPrice());
     /* imageViewHolder.day.setText(upload.getDate_start()+"至"+upload.getDate_end());*/  //刊登日期


       imageViewHolder.image_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String key = upload.getKey();
                Intent intent=new Intent(mContext,DetailActivity.class);
                intent.putExtra(user_key,key);
                mContext.startActivity(intent);

            }
        });

    }


    @Override
    public int getItemCount() {
        return mUploads.size();
    }

    public void filteredList(ArrayList<Upload> myUploads) {
        mUploads=myUploads;
        notifyDataSetChanged();
    }





    public class ImageViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener,
    View.OnCreateContextMenuListener, MenuItem.OnMenuItemClickListener {
        public TextView img_description,place,price,day;
        public ImageView image_view;

        public ImageViewHolder(@NonNull View itemView) {
            super(itemView);
            img_description=itemView.findViewById(R.id.img_description);
            image_view=itemView.findViewById(R.id.imgurl);
            place=itemView.findViewById(R.id.place);
            price=itemView.findViewById(R.id.price);
            day=itemView.findViewById(R.id.date);

            itemView.setOnClickListener(this);
            itemView.setOnCreateContextMenuListener(this);
        }

        @Override
        public boolean onMenuItemClick(MenuItem item) {
            if (mListener != null) {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {

                    switch (item.getItemId()) {
                        case 1:
                            mListener.onWhatEverClick(itemView);
                            return true;
                        case 2:
                            mListener.onDeleteClick(position);
                            return true;
                    }
                }
            }
            return false;
        }


        @Override
        public void onClick(View v) {
            if (mListener != null) {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    mListener.onItemClick(position);
                }
            }
        }

        @Override
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
            menu.setHeaderTitle("Select Action");
            MenuItem doWhatever = menu.add(Menu.NONE, 1, 1, "Do whatever");
            MenuItem delete = menu.add(Menu.NONE, 2, 2, "Delete");

            doWhatever.setOnMenuItemClickListener(this);
            delete.setOnMenuItemClickListener(this);
        }
    }
    public interface OnItemClickListener {
        void onItemClick(int position);

        void onWhatEverClick(View view);

        void onDeleteClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }


}
