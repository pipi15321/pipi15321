package com.example.appomg;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

public class Activitytwo3 extends AppCompatActivity {
ImageButton re;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activitytwo3);

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavView_Bar);
        BottomNavigationViewHelper.disableShiftMode(bottomNavigationView);
        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(true);
        re=findViewById(R.id.re);
        re.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.ic_arrow:
                        Intent intent0 = new Intent(Activitytwo3.this, home.class);
                        startActivity(intent0);
                        break;

                    case R.id.ic_android:
                        Intent intent1 = new Intent(Activitytwo3.this, ActivityOne.class);
                        startActivity(intent1);
                        break;

                    case R.id.ic_books:

                        break;

                    case R.id.ic_center_focus:
                        Intent intent3 = new Intent(Activitytwo3.this, post_user.class);
                        startActivity(intent3);
                        break;

                    case R.id.ic_backup:
                        Intent intent4 = new Intent(Activitytwo3.this, ActivityFour.class);
                        startActivity(intent4);
                        break;
                }


                return false;
            }
        });
    }
    public void publish(View view){
        Intent intent = new Intent();
        intent.setClass(Activitytwo3.this,publish2.class);
        startActivity(intent);
    }
    public void list_finish (View view) {
        Intent intent = new Intent();
        intent.setClass(Activitytwo3.this,list_finish2.class);
        startActivity(intent);
    }
    public void list_wait (View view) {
        Intent intent = new Intent();
        intent.setClass(Activitytwo3.this,list_wait2.class);
        startActivity(intent);
    }
    public void list_ing (View view) {
        Intent intent = new Intent();
        intent.setClass(Activitytwo3.this,list_ing2.class);
        startActivity(intent);
    }

}

