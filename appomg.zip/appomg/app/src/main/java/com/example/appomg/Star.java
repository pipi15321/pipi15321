package com.example.appomg;

public class Star {

    private String star;

    public Star() {


    }

    public String getStar() {
        return star;
    }

    public void setStar(String star) {
        this.star = star;
    }



}
