package com.example.appomg;


import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


import java.util.Arrays;
import java.util.HashMap;
import java.util.regex.Pattern;

public class registered extends AppCompatActivity {

    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    //"(?=.*[0-9])" +         //at least 1 digit
                    //"(?=.*[a-z])" +         //at least 1 lower case letter
                    //"(?=.*[A-Z])" +         //at least 1 upper case letter
                    "(?=.*[a-zA-Z])" +      //any letter
                    "(?=.*[@#$%^&+=])" +    //at least 1 special character
                    "(?=\\S+$)" +           //no white spaces
                    ".{4,}" +               //at least 4 characters
                    "$");

    private TextInputLayout textInputEmail;
    private TextInputLayout textInputUsername;
    private TextInputLayout textInputPassword;
    private TextInputLayout textInputPassword2;
    private TextInputLayout textInputPhoneNumber;
    private TextInputLayout textInputIdcard;
    private Uri imgUrl;
    FirebaseAuth auth;
    FirebaseAuth.AuthStateListener authListener;
    DatabaseReference ref;
    Button back,save,input;
    User user;
    private String userUID;
    EditText email,password,password2,name,nickname,phonenumber,card;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registered);
        textInputEmail = findViewById(R.id.text_input_email);
        textInputUsername = findViewById(R.id.text_input_username);
        textInputPassword = findViewById(R.id.text_input_password);
        textInputPassword2 = findViewById(R.id.text_input_password2);
        textInputPhoneNumber = findViewById(R.id.text_input_phone_number);
        textInputIdcard = findViewById(R.id.text_idcard);

        user=new User();
         /*ref=FirebaseDatabase.getInstance().getReference().child("User");*/

        email = findViewById(R.id.email);
        password=findViewById(R.id.password);
        name=findViewById(R.id.img_description);
        phonenumber=findViewById(R.id.phonenumber);
        card=findViewById(R.id.card);
        save = findViewById(R.id.save);
        back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        auth = FirebaseAuth.getInstance();

    }

    private boolean validateEmail() {
        String emailInput = textInputEmail.getEditText().getText().toString().trim();

        if (emailInput.isEmpty()) {
            textInputEmail.setError("信箱不可為空");
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()) {
            textInputEmail.setError("無效信箱");
            return false;
        } else {
            textInputEmail.setError(null);
            return true;
        }
    }

    private boolean validateUsername() {
        String usernameInput = textInputUsername.getEditText().getText().toString().trim();

        if (usernameInput.isEmpty()) {
            textInputUsername.setError("名子不可為空");
            return false;
        } else if (usernameInput.length() > 15) {
            textInputUsername.setError("名子太長");
            return false;
        } else {
            textInputUsername.setError(null);
            return true;
        }
    }

    private boolean validatePassword() {
        String passwordInput = textInputPassword.getEditText().getText().toString().trim();

        if (passwordInput.isEmpty()) {
            textInputPassword.setError("密碼不可為空");
            return false;
        } else if (passwordInput.length() < 8) {
            textInputPassword.setError("密碼太弱");
            return false;
        } else {
            textInputPassword.setError(null);
            return true;
        }
    }

    private boolean validatePassword2() {
        String passwordInput2 = textInputPassword2.getEditText().getText().toString().trim();
        String passwordInput = textInputPassword.getEditText().getText().toString().trim();
        if (passwordInput2.equals("")||passwordInput.equals("")) {
            textInputPassword2.setError("密碼不可為空");
            return false;
        } else if (passwordInput2.equals(passwordInput)) {
            SharedPreferences settings=getSharedPreferences("PREFS",0);
            SharedPreferences.Editor editor=settings.edit();
            editor.putString("password",passwordInput2);
            editor.apply();
            textInputPassword2.setError(null);
            return true;
        } else {
            textInputPassword2.setError("密碼錯誤");
            return false;
        }
    }


    private boolean validatePhoneNumber() {
        String PhoneNumberInput = textInputPhoneNumber.getEditText().getText().toString().trim();

        if (PhoneNumberInput.isEmpty()) {
            textInputPhoneNumber.setError("手機號碼不可為空");
            return false;
        } else if (PhoneNumberInput.length() ==10 ){
            return true;
        } else {
            textInputPhoneNumber.setError("手機號碼錯誤");
            return false;
        }
    }



    public void confirmInput(View v) {

        if (!validateEmail() | !validateUsername() | !validatePassword()  | !validatePhoneNumber() |!checkCardId() |!validatePassword2()) {

            return;
        }else{

            auth.createUserWithEmailAndPassword(email.getText().toString(),
                    password.getText().toString())
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {

                                user.setEmail(email.getText().toString());
                                user.setPassword(password.getText().toString());
                                user.setUsername(name.getText().toString());
                                user.setCard(card.getText().toString());
                                user.setPhone_num(phonenumber.getText().toString());
                                user.setImageURL("default");
                                 user.setStatus("offline");
                                    user.setSearch(name.getText().toString());

                                ref.child(auth.getCurrentUser().getUid()).setValue(user);
                                auth.getCurrentUser().sendEmailVerification();
                                                    Toast.makeText(registered.this, "請至信箱完成驗證", Toast.LENGTH_LONG).show();
                                Intent intent = new Intent();
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                intent.setClass(registered.this,login.class);
                                startActivity(intent);

                            } else {
                                Toast.makeText(registered.this,task.getException().getMessage(),Toast.LENGTH_LONG).show();
                            }
                        }
                    });
        }

    }
    private boolean checkCardId() {
        String id = textInputIdcard.getEditText().getText().toString().trim();
        if (!id.matches("[a-zA-Z][1-2][0-9]{8}")) {
            textInputIdcard.setError("身分證錯誤");
            return false;
        }
        if (id.matches("[a-zA-Z][1-2][0-9]{8}")) {
            textInputIdcard.setError(null);
            return true;
        }

        String newId = id.toUpperCase();
        //身分證第一碼代表數值
        int[] headNum = new int[]{
                1, 10, 19, 28, 37,
                46, 55, 64, 39, 73,
                82, 2, 11, 20, 48,
                29, 38, 47, 56, 65,
                74, 83, 21, 3, 12, 30};

        char[] headCharUpper = new char[]{
                'A', 'B', 'C', 'D', 'E', 'F', 'G',
                'H', 'I', 'J', 'K', 'L', 'M', 'N',
                'O', 'P', 'Q', 'R', 'S', 'T', 'U',
                'V', 'W', 'X', 'Y', 'Z'
        };

        int index = Arrays.binarySearch(headCharUpper, newId.charAt(0));
        int base = 8;
        int total = 0;
        for (int i = 1; i < 10; i++) {
            int tmp = Integer.parseInt(Character.toString(newId.charAt(i))) * base;
            total += tmp;
            base--;
        }

        total += headNum[index];
        int remain = total % 10;
        int checkNum = (10 - remain) % 10;
        if (Integer.parseInt(Character.toString(newId.charAt(9))) != checkNum) {
            return false;
        }
        return true;
    }
    }

