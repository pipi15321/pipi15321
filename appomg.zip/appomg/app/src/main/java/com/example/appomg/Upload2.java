package com.example.appomg;

import com.google.firebase.database.Exclude;

public class Upload2 {

    private String uid;
    private String mKey;
    private String imgName;
    private String imgUrl;
    private String imgUrl2;
    private String place;
    private String price;
    private String type;
    private String list_type;
    private String date_start;
    private String date_end;
    private String state;
    private String remark;
    private String time;
    private String from;


    public Upload2() {
    }

    public Upload2( String imgUrl) {
        if(imgName.trim().equals(""))
        {
            imgName="No name";
        }
        this.uid=uid;

        this.imgName = imgName;
        this.imgUrl = imgUrl;
        this.imgUrl2 = imgUrl2;
        this.type=type;
        this.place=place;
        this.price=price;
        this.date_start=date_start;
        this.date_end=date_end;
        this.state=state;
        this.remark=remark;
        this.time=time;
this.from=from;



    }

    public String getImgName() {
        return imgName;
    }

    public void setImgName(String imgName) {
        this.imgName = imgName;
    }

    public String getImgUrl() {
        return imgUrl;
    }
    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getImgUrl2() {
        return imgUrl2;
    }
    public void setImgUrl2(String imgUrl2) {
        this.imgUrl2 = imgUrl2;
    }



    public String getList_type() {
        return list_type;
    }

    public void setList_type(String list_type) {
        this.list_type = list_type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }


    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getFrom() {
        return from;
    }



    public void setFrom(String from) {
        this.from = from;
    }


    @Exclude
    public String getKey() {
        return mKey;
    }

    @Exclude
    public void setKey(String key) {
        mKey = key;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }




    public String getDate_start() {
        return date_start;
    }

    public void setDate_start(String date_start) {
        this.date_start = date_start;
    }

    public String getDate_end() {
        return date_end;
    }

    public void setDate_end(String date_end) {
        this.date_end = date_end;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
