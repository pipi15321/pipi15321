package com.example.appomg;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class QA extends AppCompatActivity {
private TextView b,b1,c,c1,d,d1,e,e1,f,f1,g,g1,h,h1,i,i1,j,j1,k,k1;
private ImageButton re;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q);

        re=findViewById(R.id.re);
        b=findViewById(R.id.b);
        b1=findViewById(R.id.b1);
        c=findViewById(R.id.c);
        c1=findViewById(R.id.c1);
        d=findViewById(R.id.d);
        d1=findViewById(R.id.d1);
        e=findViewById(R.id.e);
        e1=findViewById(R.id.e1);
        f=findViewById(R.id.f);
        f1=findViewById(R.id.f1);
        g=findViewById(R.id.g);
        g1=findViewById(R.id.g1);
        h=findViewById(R.id.h);
        h1=findViewById(R.id.h1);
        i=findViewById(R.id.i);
        i1=findViewById(R.id.i1);
        j=findViewById(R.id.j);
        j1=findViewById(R.id.j1);
        k=findViewById(R.id.k);
        k1=findViewById(R.id.k1);

        re.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              finish();

            }
        });

       b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              b1.setVisibility(View.VISIBLE);

            }
        });
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c1.setVisibility(View.VISIBLE);

            }
        });
        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d1.setVisibility(View.VISIBLE);

            }
        });
        e.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                e1.setVisibility(View.VISIBLE);

            }
        });
        f.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                f1.setVisibility(View.VISIBLE);

            }
        }); g.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g1.setVisibility(View.VISIBLE);

            }
        }); h.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                h1.setVisibility(View.VISIBLE);

            }
        }); j.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                j1.setVisibility(View.VISIBLE);

            }
        }); k.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                k1.setVisibility(View.VISIBLE);

            }
        }); i.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i1.setVisibility(View.VISIBLE);

            }
        });



    }
}
