package com.example.appomg;

import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import static com.example.appomg.ImageAdapter.user_key;

public class report extends AppCompatActivity {
    private DatabaseReference reff;
    private EditText txtreason;
    private Button btnsave;
    private RadioButton rbtn1,rbtn2,rbtn3,rbtn4,rbtn5,rbtn6;
     Reportreason reportreason;
    private RadioGroup rg;
    private TextView textView1,key,imageurl,tdate;
    private ImageView imageView;
    String a;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        Intent intent = getIntent();
        String text = intent.getStringExtra(DetailActivity.EXTRA_TEXT);
        textView1 = findViewById(R.id.text1);
        textView1.setText(text);
        imageView=findViewById(R.id.imageView);
        imageurl=findViewById(R.id.imageurl);
        final String Key = getIntent().getStringExtra(user_key);
        txtreason= findViewById(R.id.txtreason);
        rbtn1=findViewById(R.id.rbtn1);
        rbtn2= findViewById(R.id.rbtn2);
        rbtn3= findViewById(R.id.rbtn3);
        rbtn4= findViewById(R.id.rbtn4);
        rbtn5= findViewById(R.id.rbtn5);
        rbtn6= findViewById(R.id.rbtn6);
        btnsave=findViewById(R.id.save);
        key=findViewById(R.id.key);
        tdate = findViewById(R.id.time);
        rg = findViewById(R.id.radiogroup1);
        String url = getIntent().getStringExtra("imgurl2");
        Picasso.with(this).load(url).into(imageView);
        a=url;

        reportreason=new Reportreason();
        reff= FirebaseDatabase.getInstance().getReference().child("Reportreason");
        final String text2 = getIntent().getStringExtra("key");
        key.setText(text2);

        String text3 = getIntent().getStringExtra("imgurl");
        imageurl.setText(text3);

        Thread t = new Thread() {    //日期秒數
            @Override
            public void run() {
                try {
                    while (!isInterrupted()) {
                        Thread.sleep(1000);
                        runOnUiThread(new Runnable() {
                            @RequiresApi(api = Build.VERSION_CODES.N)
                            @Override
                            public void run() {
                                TextView tdate = (TextView) findViewById(R.id.time);
                                long date = System.currentTimeMillis();
                                SimpleDateFormat sdf = new SimpleDateFormat("yyyy - MM - dd");
                                String dateString = sdf.format(date);
                                tdate.setText(dateString);
                            }
                        });
                    }
                } catch (InterruptedException e) {
                }
            }
        };
        t.start();

        btnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (rg.getCheckedRadioButtonId()){
                    case R.id.rbtn1:

                        reportreason.setUid(textView1.getText().toString());
                        reportreason.setReason1(rbtn1.getText().toString());
                        reportreason.setContent(txtreason.getText().toString());
                        reportreason.setKey(key.getText().toString());
                        reportreason.setImageurl(imageurl.getText().toString());
                        reportreason.setTime(tdate.getText().toString());
                        reff.push().setValue(reportreason);
                        Toast.makeText(report.this, "檢舉成功!!!",Toast.LENGTH_LONG).show();
                        Intent intent = new Intent();
                        intent.setClass(report.this,home.class);
                        startActivity(intent);
                        break;

                    case R.id.rbtn2:
                        reportreason.setUid(textView1.getText().toString().trim());
                        reportreason.setReason1(rbtn2.getText().toString().trim());
                        reportreason.setContent(txtreason.getText().toString().trim());
                        reportreason.setKey(key.getText().toString().trim());
                        reportreason.setImageurl(imageurl.getText().toString().trim());
                        reportreason.setTime(tdate.getText().toString());
                        reff.push().setValue(reportreason);
                        Toast.makeText(report.this, "檢舉成功!!!",Toast.LENGTH_LONG).show();
                        Intent intent1 = new Intent();
                        intent1.setClass(report.this,home.class);
                        startActivity(intent1);
                        break;

                    case R.id.rbtn3:
                        reportreason.setUid(textView1.getText().toString().trim());
                        reportreason.setReason1(rbtn3.getText().toString().trim());
                        reportreason.setContent(txtreason.getText().toString().trim());
                        reportreason.setKey(key.getText().toString().trim());
                        reportreason.setImageurl(imageurl.getText().toString().trim());
                        reportreason.setTime(tdate.getText().toString());
                        reff.push().setValue(reportreason);
                        Toast.makeText(report.this, "檢舉成功!!!",Toast.LENGTH_LONG).show();
                        Intent intent2 = new Intent();
                        intent2.setClass(report.this,home.class);
                        startActivity(intent2);
                        break;

                    case R.id.rbtn4:
                        reportreason.setUid(textView1.getText().toString().trim());
                        reportreason.setReason1(rbtn4.getText().toString().trim());
                        reportreason.setContent(txtreason.getText().toString().trim());
                        reportreason.setKey(key.getText().toString().trim());
                        reportreason.setImageurl(imageurl.getText().toString().trim());
                        reportreason.setTime(tdate.getText().toString());
                        reff.push().setValue(reportreason);
                        Toast.makeText(report.this, "檢舉成功!!!",Toast.LENGTH_LONG).show();
                        Intent intent3 = new Intent();
                        intent3.setClass(report.this,home.class);
                        startActivity(intent3);
                        break;

                    case R.id.rbtn5:
                        reportreason.setUid(textView1.getText().toString().trim());
                        reportreason.setReason1(rbtn5.getText().toString().trim());
                        reportreason.setContent(txtreason.getText().toString().trim());
                        reportreason.setKey(key.getText().toString().trim());
                        reportreason.setImageurl(imageurl.getText().toString().trim());
                        reportreason.setTime(tdate.getText().toString());
                        reff.push().setValue(reportreason);
                        Toast.makeText(report.this, "檢舉成功!!!",Toast.LENGTH_LONG).show();
                        Intent intent4 = new Intent();
                        intent4.setClass(report.this,home.class);
                        startActivity(intent4);
                        break;

                    case R.id.rbtn6:
                        reportreason.setUid(textView1.getText().toString().trim());
                        reportreason.setReason1(rbtn6.getText().toString().trim());
                        reportreason.setContent(txtreason.getText().toString().trim());
                        reportreason.setKey(key.getText().toString().trim());
                        reportreason.setImageurl(imageurl.getText().toString().trim());
                        reportreason.setTime(tdate.getText().toString());
                        reff.push().setValue(reportreason);
                        Toast.makeText(report.this, "檢舉成功!!!",Toast.LENGTH_LONG).show();
                        Intent intent5 = new Intent();
                        intent5.setClass(report.this,home.class);
                        startActivity(intent5);
                }

            }
        });
    }

}




