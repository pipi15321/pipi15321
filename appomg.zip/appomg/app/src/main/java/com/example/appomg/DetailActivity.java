package com.example.appomg;

import android.app.FragmentManager;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.appomg.Adapter.UserAdapter;
import com.example.appomg.Fragments.UsersFragment;
import com.example.appomg.Model.User2;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.security.Key;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.example.appomg.ImageAdapter.user_key;

public class DetailActivity extends AppCompatActivity {
    public static final String EXTRA_TEXT = "com.example.application.EXTRA_TEXT";
    private TextView name, price, place, day, uid, state, type, date_end, remark, imgurl2, time, uid2,key,a,username,double_price,imageURL;
    private static final int REQUEST_CODE = 1;
    private ImageView imgurl;
    FirebaseAuth auth;
    private Button buy, add, message, report,cancel;
    DatabaseReference ref;
    DatabaseReference ref1,ref2,ref3;
    private List<Upload> mUploads;
    private List<Detail> mdatail;
    private Context mContext;
    private UserAdapter userAdapter;
    private List<User2> mUsers;
    View v;
    ImageButton re;
    User user;
    private Integer i;
private CircleImageView profile_image;
    private StorageReference mStorageRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        auth = FirebaseAuth.getInstance();
        username=findViewById(R.id.username);
        name = findViewById(R.id.name);
        buy = findViewById(R.id.buy);
        price = findViewById(R.id.price);
        place = findViewById(R.id.place);
        day = findViewById(R.id.date);
        imgurl = findViewById(R.id.imgurl);
        uid = findViewById(R.id.uid);
        uid2 = findViewById(R.id.uid2);
        message = findViewById(R.id.message);
        state = findViewById(R.id.state);
        type = findViewById(R.id.type);
        imgurl2 = findViewById(R.id.imgurl2);
        auth = FirebaseAuth.getInstance();
        remark = findViewById(R.id.remark);
        date_end = findViewById(R.id.date_end);
        re = findViewById(R.id.re);
        time = findViewById(R.id.time);
        report = findViewById(R.id.report);
        cancel = findViewById(R.id.cancel);
        final String Key = getIntent().getStringExtra(user_key);
        uid2.setText(auth.getCurrentUser().getUid());
        add= findViewById(R.id.add);
        imageURL= findViewById(R.id.imageURL);
        key=findViewById(R.id.key);
        profile_image=findViewById(R.id.profile_image);
        double_price=findViewById(R.id.double_price);
        mStorageRef = FirebaseStorage.getInstance().getReference("users");
        user = new User();
       UsersFragment myFragment = new UsersFragment();
        Bundle bundle = new Bundle();
        bundle.putString("name",username.getText().toString());//这里的values就是我们要传的值
        myFragment.setArguments(bundle);

      add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (i == 0) {
                    DatabaseReference ref1 = FirebaseDatabase.getInstance().getReference("favorite").child(auth.getCurrentUser().getUid());
                    Intent intent = new Intent();
                    intent.putExtra("key", Key); //抓key
                    intent.putExtra("name", name.getText().toString());
                    intent.putExtra("username", username.getText().toString());
                    intent.putExtra("imgurl", imgurl2.getText().toString());
                    String uploadID = ref1.push().getKey();
                    ref1.child(Key).child("imgName").setValue(name.getText().toString());
                    ref1.child(Key).child("imgUrl").setValue(imgurl2.getText().toString());
                    ref1.child(Key).child("price").setValue(price.getText().toString());
                    ref1.child(Key).child("place").setValue(place.getText().toString());
                    ref1.child(Key).child("type").setValue(type.getText().toString());
                    ref1.child(Key).child("state").setValue("1");
                    /*ref1.child(Key).child("day").setValue(day.getText().toString());*/
                    /* ref1.child(Key).child("date_end").setValue(date_end.getText().toString());*/
                    ref1.child(Key).child("remark").setValue(remark.getText().toString());
                    ref1.child(Key).child("time").setValue(time.getText().toString());
                    ref1.child(Key).child("uid").setValue(uid.getText().toString());
                    ref1.child(Key).child("double_price").setValue(double_price.getText().toString());

                    /*ref1.child(Key).child("state").setValue("1");*/
                    Toast.makeText(DetailActivity.this, "加入收藏", Toast.LENGTH_SHORT).show();
                    i = 1;


                }else{

                    Toast.makeText(DetailActivity.this, "已收藏", Toast.LENGTH_SHORT).show();
                }
            }
                /*if(i==0) {
                    DatabaseReference ref1 = FirebaseDatabase.getInstance().getReference("favorite").child(auth.getCurrentUser().getUid());
                    Intent intent = new Intent();
                    intent.putExtra("key", Key); //抓key
                    intent.putExtra("name", name.getText().toString());
                    intent.putExtra("imgurl2", imgurl2.getText().toString());
                    String uploadID = ref1.push().getKey();
                    ref1.child(Key).child("name").setValue(name.getText().toString());
                    ref1.child(Key).child("imgurl2").setValue(imgurl2.getText().toString());
                    Toast.makeText(DetailActivity.this, "加入收藏", Toast.LENGTH_LONG).show();
                    i=1;


                }if(i==1){
                    add.setEnabled(false);
                    Toast.makeText(DetailActivity.this, "已收藏", Toast.LENGTH_LONG).show();

                }*/
        });




        report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*Intent intent = new Intent();
                intent.putExtra("uid",uid.getText().toString());
                intent.setClass(DetailActivity.this,report.class);
                startActivity(intent);*/
                Intent intent = new Intent();
                intent.putExtra("key", Key); //抓key
                TextView status = (TextView) findViewById(R.id.uid);
                String text = status.getText().toString();
                intent.putExtra(EXTRA_TEXT, text);

                intent.putExtra("imgurl2", imgurl2.getText().toString());
                intent.putExtra("imgurl", imgurl2.getText().toString());
                intent.setClass(DetailActivity.this, report.class);
                startActivity(intent);
            }
        });
        re.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(DetailActivity.this, home.class);
                startActivity(intent);

            }
        });
        buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                name = findViewById(R.id.name);
                Intent intent = new Intent();
                intent.putExtra("uid", uid.getText().toString());
                intent.putExtra("name", name.getText().toString());
                intent.putExtra("username", username.getText().toString());
                intent.putExtra("price", price.getText().toString());
                intent.putExtra("place", place.getText().toString());
               /* intent.putExtra("day", day.getText().toString());*/
                intent.putExtra("type", type.getText().toString());
                intent.putExtra("state", state.getText().toString());
                intent.putExtra("date_end", date_end.getText().toString());
                intent.putExtra("remark", remark.getText().toString());
                intent.putExtra("imgurl2", imgurl2.getText().toString());
                intent.putExtra("time", time.getText().toString());
                intent.putExtra("double_price", double_price.getText().toString());
                intent.putExtra("username", username.getText().toString());
                intent.putExtra("imageURL", imageURL.getText().toString());
                intent.putExtra("key", Key); //抓key

                intent.setClass(DetailActivity.this, buy.class);
                startActivity(intent);

            }

        });


        message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent();
                intent.setClass(DetailActivity.this, MainActivity.class);
                intent.putExtra("username", username.getText().toString());
                startActivity(intent);

        }
        });

      /*  cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseReference ref1 = FirebaseDatabase.getInstance().getReference("favorite").child(auth.getCurrentUser().getUid()).child(Key);
                ref1.child("state").setValue("0");
                Toast.makeText(DetailActivity.this, "取消收藏", Toast.LENGTH_SHORT).show();
                i=0;
                cancel.setVisibility(View.GONE);
                add.setVisibility(View.VISIBLE);

            }
        });*/

        final DatabaseReference ref = FirebaseDatabase.getInstance().getReference("uploads").child(Key);

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                if ( FirebaseDatabase.getInstance().getReference("favorite").child(auth.getCurrentUser().getUid()).child(Key) == FirebaseDatabase.getInstance().getReference("uploads").child(Key)){
                    add.setEnabled(false);
                    Toast.makeText(DetailActivity.this, "已收藏過", Toast.LENGTH_LONG).show();
                    i = 1;

                }else{
                    i = 0;
                }

                Upload upload = dataSnapshot.getValue(Upload.class);
                Picasso.with(mContext)
                        .load(upload.getImgUrl())
                        .into(imgurl);

                if (upload.getImageURL().equals("default")){
                    profile_image.setImageResource(R.drawable.cyclops);
                } else {
                    Picasso.with(mContext)
                            .load(upload.getImageURL())
                            .into(profile_image);
                }


                name.setText(upload.getImgName());
                place.setText(upload.getPlace());
                price.setText(upload.getPrice());
                double_price.setText(upload.getDouble_price());
               /* day.setText(upload.getDate_start() + "至" + upload.getDate_end());

                state.setText("" + upload.getState());
                date_end.setText(upload.getDate_end());*/
                time.setText(upload.getTime());
                uid.setText(upload.getUid());
                type.setText(upload.getType());
                username.setText(upload.getUsername());
                imageURL.setText(upload.getImageURL());
                remark.setText(upload.getRemark());
                imgurl2.setText(upload.getImgUrl2());
                key.setText(Key);

                check();



            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        /*ref3 = FirebaseDatabase.getInstance().getReference().child("Users").child(uid.getText().toString());


        ref3.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                User user = dataSnapshot.getValue(User.class);
               /* Picasso.with(mContext)
                        .load(user.getImageURL())
                        .into(imgPreview);
                username.setText(user.getUsername());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });*/
    }

    public void check() {

        if (uid.getText().toString().equals(uid2.getText().toString())==true) {
           buy.setEnabled(false);
            message.setEnabled(false);
           report.setEnabled(false);
           add.setEnabled(false);
        }
        }
}

