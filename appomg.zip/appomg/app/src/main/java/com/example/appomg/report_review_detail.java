package com.example.appomg;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import static com.example.appomg.ImageAdapter.user_key;

public class report_review_detail extends AppCompatActivity {
    private TextView time,content;
    private Button comment_bt;
    private ImageButton re;
    private EditText comment;
    private ImageView imgurl;
    private Context mContext;
    Reportreason reportreason;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_review_detail);
        time=findViewById(R.id.time);
        imgurl=findViewById(R.id.imgurl);
        comment=findViewById(R.id.comment);
        comment_bt=findViewById(R.id.comment_bt);

        content=findViewById(R.id.content);
        reportreason=new Reportreason();

        String Key=getIntent().getStringExtra(user_key);
        final DatabaseReference ref= FirebaseDatabase.getInstance().getReference("notice").child(Key);

       comment_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ref.child("comment").setValue(comment.getText().toString());

                Toast.makeText(report_review_detail.this, "已送出", Toast.LENGTH_SHORT).show();
                finish();


            }
        });

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Reportreason reportreason = dataSnapshot.getValue(Reportreason.class);
                Picasso.with(mContext)
                        .load(reportreason.getImageurl())
                        .into(imgurl);
                content.setText("檢舉內容:"+reportreason.getReason1());
                time.setText("檢舉日期:"+reportreason.getTime());



            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }


}