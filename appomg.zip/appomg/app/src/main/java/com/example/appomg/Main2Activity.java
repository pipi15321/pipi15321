package com.example.appomg;

import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebSettings;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.NotNull;
import com.google.firebase.storage.FirebaseStorage;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.IndicatorView.draw.controller.DrawController;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;
import com.squareup.picasso.Picasso;
import com.synnapps.carouselview.CarouselView;
import com.synnapps.carouselview.ImageListener;


import org.w3c.dom.Text;

import java.net.MalformedURLException;
import java.util.ArrayList;

import technolifestyle.com.imageslider.FlipperLayout;
import technolifestyle.com.imageslider.FlipperView;


public class Main2Activity extends AppCompatActivity{
    /*private static final String TAG = "Main2Activity";*/
   private RecyclerView mRecyclerView;
private firstAdapter mAdapter;
    private ProgressBar progressBar;
    private FirebaseStorage mStorage;
    FirebaseAuth auth;
    private DatabaseReference mDatabaseRef;
    private ArrayList<Upload> mUploads;
    private String userUID;
    FirebaseAuth.AuthStateListener authListener;
   private EditText edit;
   private ImageButton btnsearch,START;
    private ValueEventListener mDBListener;
    View view;
    FirebaseUser firebaseUser;
    FlipperLayout flipper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        mRecyclerView = findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new  GridLayoutManager(this,2));
        progressBar = findViewById(R.id.progress_circular);
        flipper=findViewById(R.id.flipper);
        setLayout();

        edit = findViewById(R.id.edit);
        FloatingActionButton fab = findViewById(R.id.fab);
        FloatingActionButton mFabBut = (FloatingActionButton) findViewById(R.id.fab);
        mFabBut.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(Main2Activity.this, login.class);
                startActivity(intent);

            }
        });

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavView_Bar);
        BottomNavigationViewHelper.disableShiftMode(bottomNavigationView);
        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(0);
        menuItem.setChecked(true);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.ic_arrow:

                        break;

                    case R.id.ic_android:
                        Intent intent1 = new Intent(Main2Activity.this, login.class);
                        startActivity(intent1);
                        break;
                    case R.id.ic_books:


                    case R.id.ic_center_focus:
                        Intent intent3 = new Intent(Main2Activity.this, post_user.class);
                        startActivity(intent3);
                        break;

                    case R.id.ic_backup:
                        Intent intent4 = new Intent(Main2Activity.this, ActivityFour.class);
                        startActivity(intent4);
                        break;
                }


                return false;
            }
        });


        auth = FirebaseAuth.getInstance();
        mUploads = new ArrayList<>();
        btnsearch = findViewById(R.id.btnsearch);
            edit.addTextChangedListener(new TextWatcher() {
                                            @Override
                                            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                                            }

                                            @Override
                                            public void onTextChanged(CharSequence s, int start, int before, int count) {

                                            }

                                            @Override
                                            public void afterTextChanged(Editable s) {
                                                filter(s.toString());
                                            }
                                        });

        mDatabaseRef = FirebaseDatabase.getInstance().getReference("uploads");
        mDBListener = mDatabaseRef.addValueEventListener(new ValueEventListener()  {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            mUploads.clear();

                            for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                Upload upload = postSnapshot.getValue(Upload.class);
                                upload.setKey(postSnapshot.getKey());
                                mUploads.add(upload);
                            }
                           mAdapter = new firstAdapter(Main2Activity.this, mUploads);
                            mRecyclerView.setAdapter(mAdapter);

                            mAdapter.notifyDataSetChanged();
                            progressBar.setVisibility(View.INVISIBLE);

                        }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        run2(view);

                }

    private void filter(String text) {
        ArrayList<Upload>myUploads=new ArrayList<>();
        for(Upload item:mUploads){
            if(item.getImgName().toLowerCase().contains(text.toLowerCase())){
                myUploads.add(item);
            }

        }
        mAdapter.filteredList(myUploads);
        mRecyclerView.setAdapter(mAdapter);
    }

    public void login(View view) {
        Intent intent = new Intent();
        intent.setClass(Main2Activity.this, login.class);
        startActivity(intent);
    }

    public void logout(View view){
            auth.getInstance().signOut();
            Intent intent = new Intent();
            intent.setClass(Main2Activity.this, home.class);
            startActivity(intent);
        }
    public void run2(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("uploads").orderByChild("state").equalTo("1");
        query.addListenerForSingleValueEvent(mDBListener);

    } public void res(View view) {
        Intent intent = new Intent();
        intent.setClass(Main2Activity.this, RegisterActivity.class);
        startActivity(intent);
    }
    private void setLayout() {
        String url[]=new String[]{

                "https://firebasestorage.googleapis.com/v0/b/appomg-6317e.appspot.com/o/uploads%2F1575217190786.png?alt=media&token=5643ac7f-4717-4405-aeff-ebd635f4a6dd",
                "https://firebasestorage.googleapis.com/v0/b/appomg-6317e.appspot.com/o/uploads%2F1575217204315.png?alt=media&token=8c7befdf-fe91-46bc-89c0-790061ea0c60",
                "https://images.pexels.com/photos/218983/pexels-photo-218983.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
        };
        for (int i = 0; i < 3;i++){
            FlipperView view=new FlipperView(getBaseContext());
            view.setImageUrl(url[i])
                    .setDescription("");
            flipper.addFlipperView(view);
            view.setOnFlipperClickListener(new FlipperView.OnFlipperClickListener() {
                @Override
                public void onFlipperClick(FlipperView flipperView) {
                    Toast.makeText(Main2Activity.this,""+flipper.getCurrentPagePosition(),Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
    public void one(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("uploads").orderByChild("type").equalTo("3C產品");
        query.addListenerForSingleValueEvent(mDBListener);
    }
    public void two(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("uploads").orderByChild("type").equalTo("電器產品");
        query.addListenerForSingleValueEvent(mDBListener);
    }
    public void three(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("uploads").orderByChild("type").equalTo("文具書籍");
        query.addListenerForSingleValueEvent(mDBListener);
    }
    public void four(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("uploads").orderByChild("type").equalTo("居家生活");
        query.addListenerForSingleValueEvent(mDBListener);
    }
    public void five(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("uploads").orderByChild("type").equalTo("衣服配飾");
        query.addListenerForSingleValueEvent(mDBListener);
    }
    public void six(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("uploads").orderByChild("type").equalTo("休閒娛樂");
        query.addListenerForSingleValueEvent(mDBListener);
    }

    }