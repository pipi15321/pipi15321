package com.example.appomg;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static com.example.appomg.ImageAdapter.user_key;

public class list_finish_detail extends AppCompatActivity {
    private TextView name, price, place, day, imgurl2, uid,time,host2,date_end,comment_tv,give,comment_tv2,star_tv,star_tv2,double_price;
    private ImageView imgurl,star;
    FirebaseAuth auth;
    Order order;
    private ImageButton edit, delete, re;
    DatabaseReference ref;
    private List<Order> mUploads;
    private Context mContext;
    private FirebaseStorage mStorage;
    private ValueEventListener mDBListener;
    private int position;
    String a,b;
    private EditText comment_to_renter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_finish_detail);
        name=findViewById(R.id.name);
        price=findViewById(R.id.price);
        double_price=findViewById(R.id.double_price);
        place=findViewById(R.id.place);
        time=findViewById(R.id.time);
        imgurl=findViewById(R.id.imgurl);
        date_end=findViewById(R.id.date_end);
        give=findViewById(R.id.give);
        auth = FirebaseAuth.getInstance();
        comment_tv=findViewById(R.id.comment_tv);
        comment_tv2=findViewById(R.id.comment_tv2);
        uid=findViewById(R.id.uid);
        host2=findViewById(R.id.host2);
        star_tv=findViewById(R.id.star_tv);
        star_tv2=findViewById(R.id.star_tv2);
        star=findViewById(R.id.star);
        String Key=getIntent().getStringExtra(user_key);
        final DatabaseReference ref= FirebaseDatabase.getInstance().getReference("order").child(Key);
        /*comment_to_renter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ref.child("renter_comment").setValue(comment_to_renter.getText().toString());
                ref.child("status").setValue("3");
            }
        });
        comment_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ref.child("borrower_comment").setValue(comment.getText().toString());
                ref.child("status").setValue("3");
            }
        });*/
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Order order=dataSnapshot.getValue(Order.class);
                Picasso.with(mContext)
                        .load(order.getImgUrl())
                        .into(imgurl);
                name.setText(order.getName());
                place.setText(order.getPlace());
                price.setText(order.getPrice());
                double_price.setText("押金:$"+order.getDouble_price());
                time.setText(order.getDay());
                /*give.setText("評語者"+order.getBorrower());*/

                if ("".equals(comment_tv)){
                    comment_tv.setText("尚無評語");
                } else {
                    comment_tv.setText("評語:"+order.getRenter_comment());
                }
                /*comment_tv.setText("評語:"+order.getRenter_comment());*/
                if ("".equals(comment_tv2)){
                    comment_tv.setText("尚無評語");
                } else {
                    comment_tv2.setText("評語:"+order.getBorrower_comment());
                }


               /* comment_tv2.setText("評語:"+order.getBorrower_comment());*/

                if ("".equals(star_tv)){
                   star_tv.setText("尚無評語");
                } else {
                    star_tv.setText(order.getRenter_star()+"顆");
                }

                /*star_tv.setText(order.getRenter_star()+"顆");*/


                if ("".equals(star_tv2)){
                    star_tv.setText("尚無評語");
                } else {
                    star_tv2.setText(order.getBorrower_star()+"顆");
                }
                /*star_tv2.setText(order.getBorrower_star()+"顆");*/
                uid.setText(order.getRenter());
                host2.setText(auth.getCurrentUser().getUid());
                a=uid.getText().toString();
                b=host2.getText().toString();
                if(a.equals(b)==false ){
                    comment_tv.setVisibility(View.GONE);
                    comment_tv2.setVisibility(View.VISIBLE);
                    star_tv2.setVisibility(View.VISIBLE);
                    star_tv.setVisibility(View.GONE);
                }else{
                    comment_tv2.setVisibility(View.GONE);
                    comment_tv.setVisibility(View.VISIBLE);
                    star_tv2.setVisibility(View.GONE);
                    star_tv.setVisibility(View.VISIBLE);
                }



            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
    public void re(View view) {
       finish();
    }
    public void comment(){
        a=uid.getText().toString();
        b=host2.getText().toString();
        if(a.equals(b)==false ){
            comment_tv.setVisibility(View.VISIBLE);
            comment_tv2.setVisibility(View.INVISIBLE);
        }else{
            comment_tv2.setVisibility(View.VISIBLE);
            comment_tv.setVisibility(View.INVISIBLE);
        }
    }

    }
