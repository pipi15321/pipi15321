package com.example.appomg;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.appomg.Model.User2;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.rengwuxian.materialedittext.MaterialEditText;

import java.util.Arrays;
import java.util.HashMap;
import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity {

   EditText username, email, password,phonenumber,card;
    Button btn_register;

    FirebaseAuth auth;
    DatabaseReference reference;

    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    //"(?=.*[0-9])" +         //at least 1 digit
                    //"(?=.*[a-z])" +         //at least 1 lower case letter
                    //"(?=.*[A-Z])" +         //at least 1 upper case letter
                    "(?=.*[a-zA-Z])" +      //any letter
                    "(?=.*[@#$%^&+=])" +    //at least 1 special character
                    "(?=\\S+$)" +           //no white spaces
                    ".{4,}" +               //at least 4 characters
                    "$");

    private TextInputLayout textInputEmail;
    private TextInputLayout textInputUsername;
    private TextInputLayout textInputPassword;
    private TextInputLayout textInputPassword2;
    private TextInputLayout textInputPhoneNumber;
    private TextInputLayout textInputIdcard;

    FirebaseAuth.AuthStateListener authListener;
    DatabaseReference ref;
    Button back,save,input;
    User2 user2;
    private String userUID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        /*Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Register");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);*/

        textInputEmail = findViewById(R.id.text_input_email);
        textInputUsername = findViewById(R.id.text_input_username);
        textInputPassword = findViewById(R.id.text_input_password);
        textInputPassword2 = findViewById(R.id.text_input_password2);
        textInputPhoneNumber = findViewById(R.id.text_input_phone_number);
        textInputIdcard = findViewById(R.id.text_idcard);

        username = findViewById(R.id.username);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        btn_register = findViewById(R.id.btn_register);

        auth = FirebaseAuth.getInstance();


        phonenumber=findViewById(R.id.phonenumber);
        card=findViewById(R.id.card);


        auth = FirebaseAuth.getInstance();


        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String txt_username = username.getText().toString();
                String txt_email = email.getText().toString();
                String txt_password = password.getText().toString();
                String txt_card = card.getText().toString();
                String txt_phone_num = phonenumber.getText().toString();
                if (!validateEmail() | !validateUsername() | !validatePassword()  | !validatePhoneNumber() |!checkCardId() |!validatePassword2()) {

                    return;
                }
               else {
                    register(txt_username, txt_email, txt_password,txt_card,txt_phone_num);
                }
            }
        });

    }




    private void register(final String username, final String email, final String password, final String card, final String phone_num){
        auth.createUserWithEmailAndPassword(email, password)

                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){

                            FirebaseUser firebaseUser = auth.getCurrentUser();
                            assert firebaseUser != null;
                            String userid = firebaseUser.getUid();

                            reference = FirebaseDatabase.getInstance().getReference("Users").child(userid);

                            HashMap<String, String> hashMap = new HashMap<>();
                            hashMap.put("id", userid);
                            hashMap.put("username", username);
                            hashMap.put("imageURL", "default");
                            hashMap.put("status", "offline");
                            hashMap.put("card", card);
                            hashMap.put("phone_num", phone_num);
                            hashMap.put("email", email);
                            hashMap.put("password", password);
                            hashMap.put("search", username.toLowerCase());

                            auth.getCurrentUser().sendEmailVerification();
                            Toast.makeText(RegisterActivity.this, "請至信箱完成驗證", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(RegisterActivity.this, Main2Activity.class);

                            reference.setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()){

                                        Intent intent = new Intent(RegisterActivity.this, Main2Activity.class);
                                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                        finish();
                                    }
                                }
                            });
                        } else {
                            Toast.makeText(RegisterActivity.this, "You can't register woth this email or password", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
    private boolean validateEmail() {
        String emailInput = textInputEmail.getEditText().getText().toString().trim();

        if (emailInput.isEmpty()) {
            textInputEmail.setError("信箱不可為空");
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()) {
            textInputEmail.setError("無效信箱");
            return false;
        } else {
            textInputEmail.setError(null);
            return true;
        }
    }

    private boolean validateUsername() {
        String usernameInput = textInputUsername.getEditText().getText().toString().trim();

        if (usernameInput.isEmpty()) {
            textInputUsername.setError("名子不可為空");
            return false;
        } else if (usernameInput.length() > 15) {
            textInputUsername.setError("名子太長");
            return false;
        } else {
            textInputUsername.setError(null);
            return true;
        }
    }

    private boolean validatePassword() {
        String passwordInput = textInputPassword.getEditText().getText().toString().trim();

        if (passwordInput.isEmpty()) {
            textInputPassword.setError("密碼不可為空");
            return false;
        } else if (passwordInput.length() < 8) {
            textInputPassword.setError("密碼太弱");
            return false;
        } else {
            textInputPassword.setError(null);
            return true;
        }
    }

    private boolean validatePassword2() {
        String passwordInput2 = textInputPassword2.getEditText().getText().toString().trim();
        String passwordInput = textInputPassword.getEditText().getText().toString().trim();
        if (passwordInput2.equals("")||passwordInput.equals("")) {
            textInputPassword2.setError("密碼不可為空");
            return false;
        } else if (passwordInput2.equals(passwordInput)) {
            SharedPreferences settings=getSharedPreferences("PREFS",0);
            SharedPreferences.Editor editor=settings.edit();
            editor.putString("password",passwordInput2);
            editor.apply();
            textInputPassword2.setError(null);
            return true;
        } else {
            textInputPassword2.setError("密碼錯誤");
            return false;
        }
    }


    private boolean validatePhoneNumber() {
        String PhoneNumberInput = textInputPhoneNumber.getEditText().getText().toString().trim();

        if (PhoneNumberInput.isEmpty()) {
            textInputPhoneNumber.setError("手機號碼不可為空");
            return false;
        } else if (PhoneNumberInput.length() ==10 ){
            return true;
        } else {
            textInputPhoneNumber.setError("手機號碼錯誤");
            return false;
        }
    }
    private boolean checkCardId() {
        String id = textInputIdcard.getEditText().getText().toString().trim();
        if (!id.matches("[a-zA-Z][1-2][0-9]{8}")) {
            textInputIdcard.setError("身分證錯誤");
            return false;
        }
        if (id.matches("[a-zA-Z][1-2][0-9]{8}")) {
            textInputIdcard.setError(null);
            return true;
        }

        String newId = id.toUpperCase();
        //身分證第一碼代表數值
        int[] headNum = new int[]{
                1, 10, 19, 28, 37,
                46, 55, 64, 39, 73,
                82, 2, 11, 20, 48,
                29, 38, 47, 56, 65,
                74, 83, 21, 3, 12, 30};

        char[] headCharUpper = new char[]{
                'A', 'B', 'C', 'D', 'E', 'F', 'G',
                'H', 'I', 'J', 'K', 'L', 'M', 'N',
                'O', 'P', 'Q', 'R', 'S', 'T', 'U',
                'V', 'W', 'X', 'Y', 'Z'
        };

        int index = Arrays.binarySearch(headCharUpper, newId.charAt(0));
        int base = 8;
        int total = 0;
        for (int i = 1; i < 10; i++) {
            int tmp = Integer.parseInt(Character.toString(newId.charAt(i))) * base;
            total += tmp;
            base--;
        }

        total += headNum[index];
        int remain = total % 10;
        int checkNum = (10 - remain) % 10;
        if (Integer.parseInt(Character.toString(newId.charAt(9))) != checkNum) {
            return false;
        }
        return true;
    }
}
