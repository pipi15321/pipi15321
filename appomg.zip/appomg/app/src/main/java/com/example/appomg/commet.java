package com.example.appomg;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.Toast;

public class commet extends AppCompatActivity {
    RatingBar ratingBar;
    Button finish;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_commet);

        ratingBar=findViewById(R.id.ratingBar);
        ratingBar.setMax(5);
        finish=findViewById(R.id.finish);
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String r=String.valueOf(ratingBar.getRating());
                Toast.makeText(commet.this,r+"顆星",Toast.LENGTH_SHORT).show();
            }
        });
    }
}
