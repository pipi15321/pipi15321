package com.example.appomg;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class report_review extends AppCompatActivity {
    private static final String TAG = "Main2Activity";
    private ChildEventListener mchildListener;
    private ValueEventListener mDBListener;
    private RecyclerView mRecyclerView;
    View view;
    private DatabaseReference mDatabaseRef;
    private List<Reportreason> mUploads;
    private ReprotAdapter mAdapter;
    private Context mContext;
    private FirebaseStorage mStorage;
    FirebaseRecyclerAdapter<Reportreason, RecyclerView.ViewHolder> adapter;
    private SearchView searchView;
    private ViewPager mViewPager;
    private String userUID;
    FirebaseAuth auth;
    private EditText edit;
    FirebaseAuth.AuthStateListener authListener;
    private int position;
    private ImageButton re;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_review);

        auth = FirebaseAuth.getInstance();
        re=findViewById(R.id.re);
        edit = findViewById(R.id.edit);
        mRecyclerView = findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mStorage = FirebaseStorage.getInstance();
        mUploads = new ArrayList<>();
        mDatabaseRef = FirebaseDatabase.getInstance().getReference("notice");

      re.setOnClickListener(new View.OnClickListener() {  //
            @Override
            public void onClick(View view) {
             finish();
            }
        });
      /*  edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });*/
        /*mDatabaseRef = FirebaseDatabase.getInstance().getReference("uploads");*/


    }

    @Override
    protected void onStart() {
        super.onStart();
        mDatabaseRef = FirebaseDatabase.getInstance().getReference("notice");
        mDBListener = mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mUploads.clear();

                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Reportreason reportreason = postSnapshot.getValue(Reportreason.class);
                    reportreason.setKey(postSnapshot.getKey());
                    mUploads.add(reportreason);
                }
                mAdapter = new ReprotAdapter(report_review.this, mUploads);
                mRecyclerView.setAdapter(mAdapter);
                mAdapter.notifyDataSetChanged();

            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        run2(view);

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mDatabaseRef.removeEventListener(mDBListener);
    }


    private void filter(String text) {
        ArrayList<Reportreason> myUploads = new ArrayList<>();
        for (Reportreason item : mUploads) {
            if (item.getTime().toLowerCase().contains(text.toLowerCase())) {
                myUploads.add(item);
            }

        }
        mAdapter.filteredList(myUploads);
        mRecyclerView.setAdapter(mAdapter);
    }

    public void run2(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("notice").orderByChild("uid").equalTo(auth.getCurrentUser().getUid());
        query.addListenerForSingleValueEvent(mDBListener);
    }
}