package com.example.appomg;

import android.app.Activity;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ActivityOne extends AppCompatActivity {
    private static final String TAG = "ActivityOne";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one);

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavView_Bar);
        BottomNavigationViewHelper.disableShiftMode(bottomNavigationView);
        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(1);
        menuItem.setChecked(true);



        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.ic_arrow:
                        Intent intent0 = new Intent(ActivityOne.this, home.class);
                        startActivity(intent0);
                        break;

                    case R.id.ic_android:

                        break;

                    case R.id.ic_books:
                        Intent intent2 = new Intent(ActivityOne.this, ActivityTwo.class);
                        startActivity(intent2);
                        break;

                    case R.id.ic_center_focus:
                        Intent intent3 = new Intent(ActivityOne.this, post_user.class);
                        startActivity(intent3);
                        break;

                    case R.id.ic_backup:
                        Intent intent4 = new Intent(ActivityOne.this, QA.class);
                        startActivity(intent4);
                        break;
                }

                return false;
            }
        });


    }
    public void edit (View view) {
        Intent intent = new Intent();
        intent.setClass(ActivityOne.this, Account.class);
        startActivity(intent);
    }
    public void chat (View view) {
        Intent intent = new Intent();
        intent.setClass(ActivityOne.this, MainActivity.class);
        startActivity(intent);
    }
    public void heart (View view) {
        Intent intent = new Intent();
        intent.setClass(ActivityOne.this, heart.class);
        startActivity(intent);
    }
    public void comment (View view) {
        Intent intent = new Intent();
        intent.setClass(ActivityOne.this, list_comment.class);
        startActivity(intent);
    }
    public void report (View view) {
        Intent intent = new Intent();
        intent.setClass(ActivityOne.this, report_review.class);
        startActivity(intent);
    }
}
