package com.example.appomg;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.security.Key;
import java.time.Year;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

@RequiresApi(api = Build.VERSION_CODES.N)
public class buy extends AppCompatActivity {
    private TextView name, price, day, uid,place,state,type,date_end,remark,time,date, date2,sum,double_price,username,imageURL,host_name;
    private Button order_bt;
    private ImageView imgurl;
    FirebaseAuth auth;
    private List<Upload> mUploads;
    private Context mContext;
    String a;
    Order order;
    Upload upload;
    private ImageButton time_bt, time_bt2;
    private StorageReference mStorageRef;
    private DatabaseReference mDatabaseRef,ref,ref1,ref2;
    int year;
    int month;
    int dayOfMonth;
    Calendar calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy);
        uid = findViewById(R.id.uid);
        imgurl = findViewById(R.id.imgurl);
        price = findViewById(R.id.price);
        double_price = findViewById(R.id.double_price);
        day = findViewById(R.id.day);
        type=findViewById(R.id.type);
        place=findViewById(R.id. place);
        state=findViewById(R.id.state);
        date_end=findViewById(R.id.date_end);
        order_bt=findViewById(R.id.order_bt);
        remark=findViewById(R.id.remark);
        time=findViewById(R.id.time);
         time_bt = findViewById(R.id.time_bt);
        time_bt2 = findViewById(R.id.time_bt2); //時間按鈕
         date = findViewById(R.id.date);
        date2 = findViewById(R.id.date2);

        username = findViewById(R.id.username);
        host_name = findViewById(R.id.host_name);
        imageURL = findViewById(R.id.imageURL);
        String text1 = getIntent().getStringExtra("name");
        String text4 = getIntent().getStringExtra("uid");
        String text2 = getIntent().getStringExtra("price");
        /*String text3 = getIntent().getStringExtra("day");*/
        String url = getIntent().getStringExtra("imgurl2");
        String text5 = getIntent().getStringExtra("type");
        String text6 = getIntent().getStringExtra("state");
        String text7 = getIntent().getStringExtra("place");
        /*String text8 = getIntent().getStringExtra("date_end");*/
       String text9 = getIntent().getStringExtra("remark");
        String text10 = getIntent().getStringExtra("time");
        final String text11 = getIntent().getStringExtra("key");
        String text12 = getIntent().getStringExtra("double_price");
        String text13 = getIntent().getStringExtra("username");
        String text14 = getIntent().getStringExtra("imageURL");

        Picasso.with(this).load(url).into(imgurl);
        a=url;
        name = findViewById(R.id.name);
        name.setText(text1);
        price.setText(text2);
        /*day.setText(text3);*/

        uid.setText(text4);
        type.setText(text5);
       state.setText(text6);
       place.setText(text7);
      /*  date_end.setText(text8);*/
       remark.setText(text9);
       time.setText(text10);
        double_price.setText(text12);
       username.setText(text13);
        imageURL.setText(text14);
        order = new Order();
        auth = FirebaseAuth.getInstance();
        ref2 = FirebaseDatabase.getInstance().getReference().child("Users").child(auth.getCurrentUser().getUid());

        ref2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User user = dataSnapshot.getValue(User.class);
               host_name.setText(user.getUsername());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        time_bt.setOnClickListener(new View.OnClickListener() {  //
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(buy.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {

                                date.setText(year + "-" + (month+1) + "-" + day);
                            }
                        }, 0, -1, 0);
                datePickerDialog.show();
            }
        });
        time_bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(buy.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {


                                date2.setText(year + "-" + (month+1) + "-" + day);
                            }
                        }, 0, -1 ,0);
                datePickerDialog.show();
            }
        });

       order_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (date.getText().toString() !="" && date2.getText().toString()!=""){
                    new AlertDialog.Builder(buy.this)
                            .setTitle("下單確認")
                            .setMessage("請確認填寫資訊是否正確，確認後請按下確定，完成下單程序。")
                            .setPositiveButton("確定",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("order");
                                            ref1 = FirebaseDatabase.getInstance().getReference().child("favorite").child(auth.getCurrentUser().getUid());
                                            String orderID = mDatabaseRef.push().getKey();

                                            order.setUid(uid.getText().toString());
                                            order.setPrice(price.getText().toString());

                                            order.setPlace(place.getText().toString());
                                            order.setName(name.getText().toString());
                                            order.setDay(date.getText().toString()+"至"+date2.getText().toString());
                                            order.setType(type.getText().toString());
                                            order.setState(state.getText().toString());
                                            order.setHost(auth.getCurrentUser().getUid());
                                            order.setDate_end(date2.getText().toString());
                                            order.setRemark(remark.getText().toString());
                                            order.setImgUrl(a);
                                            order.setTime(time.getText().toString());

                                            order.setDouble_price(double_price.getText().toString());
                                            order.setUsername(username.getText().toString());
                                            order.setImageURL(imageURL.getText().toString());
                                            order.setHost_name(host_name.getText().toString());
                                            ref = FirebaseDatabase.getInstance().getReference().child("uploads");

                                            /*ref1.child(text11).child("state").setValue("0");*/ //

                                            order.setState(state.getText().toString());
                                            mDatabaseRef.child(orderID).setValue(order);
                                            Toast.makeText(buy.this, "成功下單", Toast.LENGTH_SHORT).show();
                                            finish();
                                            Intent intent = new Intent();
                                            intent.setClass(buy.this, list_wait.class);
                                            startActivity(intent);

                                        }
                                    })
                            .setNeutralButton("取消", null)
                            .show();

                }  else{
                    Toast.makeText(buy.this, "租用日期未填寫", Toast.LENGTH_SHORT).show();
                }
                }

        });

    }

    /*public void ORDER(View view) {
        String orderID = mDatabaseRef.push().getKey();
        mDatabaseRef.child(orderID).setValue(order);
        order.setUid(uid.getText().toString());
        order.setPrice(price.getText().toString());
        order.setPlace(place.getText().toString());
        order.setUid(uid.getText().toString());
        order.setName(name.getText().toString());
        order.setDay(day.getText().toString());
       order.setType(type.getText().toString());
        order.setState(state.getText().toString());
        order.setHost(auth.getCurrentUser().getUid());
        order.setDate_end(date_end.getText().toString());

        order.setImgUrl(a);
        Toast.makeText(buy.this, "下單成功", Toast.LENGTH_SHORT).show();
    }*/


    }
