package com.example.appomg;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.core.Repo;
import com.google.firebase.storage.FirebaseStorage;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class ReprotAdapter extends RecyclerView.Adapter<ReprotAdapter.ImageViewHolder> {
    private Context mContext;
    private FirebaseStorage mStorage;
    private List<Reportreason> mUploads;
    private OnItemClickListener mListener;
    View view;
public static final String user_key="User_key";
    public ReprotAdapter(Context context, List<Reportreason> uploads)
    {
        this.mContext=context;
        this.mUploads=uploads;
    }



    @NonNull
    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v= LayoutInflater.from(mContext).inflate(R.layout.reprot_layout, viewGroup,false);
        return  new ImageViewHolder(v);
    }


    @Override
    public void onBindViewHolder(@NonNull ImageViewHolder imageViewHolder, int i) {
        /*final Upload uploadCur = mUploads.get(i);*/
           final Reportreason reportreason=mUploads.get(i);
        Picasso.with(mContext)
                .load(reportreason.getImageurl())
                .placeholder(R.drawable.imagepreview)
                .fit()
                .centerCrop()
                .into(imageViewHolder.imgurl);

       imageViewHolder.title.setText("檢舉");
        imageViewHolder.content.setText("內容:"+reportreason.getReason1());
        imageViewHolder.date.setText(reportreason.getTime());
        /*imageViewHolder.day.setText(upload.getDate_start()+"至"+upload.getDate_end()); */ //刊登日期

        imageViewHolder.imgurl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String key = reportreason.getKey();
                Intent intent=new Intent(mContext,report_review_detail.class);
                intent.putExtra(user_key,key);
                mContext.startActivity(intent);

            }
        });


    }


    @Override
    public int getItemCount() {
        return mUploads.size();
    }

    public void filteredList(ArrayList<Reportreason> myUploads) {
        mUploads=myUploads;
        notifyDataSetChanged();
    }





    public class ImageViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener,
    View.OnCreateContextMenuListener, MenuItem.OnMenuItemClickListener {
        public TextView date,title,content;
        public ImageView imgurl;


        public ImageViewHolder(@NonNull View itemView) {
            super(itemView);
           date=itemView.findViewById(R.id.date);
           title=itemView.findViewById(R.id.title);
           content=itemView.findViewById(R.id.content);
           imgurl=itemView.findViewById(R.id.imgurl);

            itemView.setOnClickListener(this);
            itemView.setOnCreateContextMenuListener(this);
        }

        @Override
        public boolean onMenuItemClick(MenuItem item) {
            if (mListener != null) {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {

                    switch (item.getItemId()) {
                        case 1:
                            mListener.onWhatEverClick(itemView);
                            return true;
                        case 2:
                            mListener.onDeleteClick(position);
                            return true;
                    }
                }
            }
            return false;
        }


        @Override
        public void onClick(View v) {
            if (mListener != null) {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    mListener.onItemClick(position);
                }
            }
        }

        @Override
        public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
            menu.setHeaderTitle("Select Action");
            MenuItem doWhatever = menu.add(Menu.NONE, 1, 1, "Do whatever");
            MenuItem delete = menu.add(Menu.NONE, 2, 2, "Delete");

            doWhatever.setOnMenuItemClickListener(this);
            delete.setOnMenuItemClickListener(this);
        }
    }
    public interface OnItemClickListener {
        void onItemClick(int position);

        void onWhatEverClick(View view);

        void onDeleteClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }


}
