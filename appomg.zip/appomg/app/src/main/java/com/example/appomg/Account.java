package com.example.appomg;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.HashMap;

public class Account extends AppCompatActivity {
    private static final int CHOOSE_IMAGE = 1;
    Button user_bt, upload,a_bt,b_bt;
    DatabaseReference ref;
    FirebaseAuth auth;
    private EditText a, b, c, d, e;
    private Uri imgUrl;
    private String userUID;
    private EditText mEmail, mPassword;
    private StorageReference mStorageRef;
    FirebaseAuth.AuthStateListener authListener;
    User user;
    ImageView imgPreview;
    ImageButton re, edit;
    private StorageTask mUploadTask;
    private ProgressBar uploadProgress;
    private Context mContext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        a = findViewById(R.id.img_description);
        b = findViewById(R.id.email);
        c = findViewById(R.id.phone);
        d = findViewById(R.id.password);
        imgPreview = findViewById(R.id.imgPreview);
        upload = findViewById(R.id.upload);
        e = findViewById(R.id.card);
        re = findViewById(R.id.re);
        edit = findViewById(R.id.edit);
        auth = FirebaseAuth.getInstance();
        uploadProgress = findViewById(R.id.uploadProgress);
        user = new User();
        ref = FirebaseDatabase.getInstance().getReference().child("Users").child(auth.getUid());
        mStorageRef = FirebaseStorage.getInstance().getReference("users");
        userUID = ref.push().getKey();
        auth = FirebaseAuth.getInstance();
        re.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
a_bt=findViewById(R.id.a_bt);
b_bt=findViewById(R.id.b_bt);
        imgPreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              showFileChoose();
            }
        });
        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uploadImage();
            }
        });
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String email = dataSnapshot.child("email").getValue().toString();
                String username = dataSnapshot.child("username").getValue().toString();
                String phone_num = dataSnapshot.child("phone_num").getValue().toString();
                String password = dataSnapshot.child("password").getValue().toString();
                String card = dataSnapshot.child("card").getValue().toString();
                String imageURL = dataSnapshot.child("imageURL").getValue().toString();

                a.setText(username);
                b.setText(email);
                c.setText(phone_num);
                d.setText(password);
                e.setText(card);
                if ("default".equals(imageURL)){
                    imgPreview.setImageResource(R.drawable.cyclops);
                } else {
                    Picasso.with(mContext).load(imageURL).into(imgPreview);
                }


                }





            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void back(View view) {
        a.setEnabled(true);
        b.setEnabled(true);
        c.setEnabled(true);
        d.setEnabled(true);
        e.setEnabled(true);
        a_bt.setVisibility(View.VISIBLE);
        b_bt.setVisibility(View.VISIBLE);

    }

    public void edit(View view) {
        ref.child("username").setValue(a.getText().toString());
        ref.child("email").setValue(b.getText().toString());
        ref.child("phone_num").setValue(c.getText().toString());
        ref.child("password").setValue(d.getText().toString());
        ref.child("card").setValue(e.getText().toString());
        a_bt.setVisibility(View.GONE);
        b_bt.setVisibility(View.GONE);

        a.setEnabled(false);
        b.setEnabled(false);
        c.setEnabled(false);
        d.setEnabled(false);
        e.setEnabled(false);


    }

    public void CANCEL(View view) {

        a_bt.setVisibility(View.GONE);
        b_bt.setVisibility(View.GONE);

        a.setEnabled(false);
        b.setEnabled(false);
        c.setEnabled(false);
        d.setEnabled(false);
        e.setEnabled(false);


    }

    private void showFileChoose() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, CHOOSE_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CHOOSE_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imgUrl = data.getData();

            Picasso.with(this).load(imgUrl).into(imgPreview);
        }

    }

    private String getFileExtension(Uri uri) {
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    private void uploadImage() {

        if (imgUrl != null ){


            final StorageReference fileReference = mStorageRef.child(System.currentTimeMillis() + "." + getFileExtension(imgUrl));

            mUploadTask = fileReference.putFile(imgUrl)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    uploadProgress.setProgress(0);
                                }
                            }, 500);
                            fileReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                   ref.child("imageURL").setValue(uri.toString());

                                }
                            });


                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {

                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                            uploadProgress.setProgress((int) progress);
                        }
                    });
        } else {

        }
    }
}





