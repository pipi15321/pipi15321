package com.example.appomg;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class Searchadapter extends RecyclerView.Adapter<Searchadapter.MyViewHolder> {
    List<Upload> mUploads;
    private Context mContext;

    public Searchadapter(Context context,ArrayList<Upload> mUploads) {
        mContext=context;
        this.mUploads=mUploads;
    }

    @NonNull
    @Override
    public Searchadapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.image_item,viewGroup,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Searchadapter.MyViewHolder myViewHolder, int i) {
        Upload uploadCur=mUploads.get(i);
        myViewHolder.img_description.setText(mUploads.get(i).getImgName());
        Picasso.with(mContext)
                .load(uploadCur.getImgUrl())
                .placeholder(R.drawable.imagepreview)
                .fit()
                .centerCrop()
                .into(myViewHolder.image_view);

        myViewHolder.place.setText(uploadCur.getPlace());
        myViewHolder.price.setText(uploadCur.getPrice());
        /*myViewHolder.day.setText(uploadCur.getDay());*/

    }

    @Override
    public int getItemCount() {
        return mUploads.size();
    }
    class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView img_description,place,price,day;
        public ImageView image_view;
        public MyViewHolder(@NonNull View itemView){
            super(itemView);
            img_description=itemView.findViewById(R.id.img_description);
            image_view=itemView.findViewById(R.id.imgurl);
            place=itemView.findViewById(R.id.place);
            price=itemView.findViewById(R.id.price);
            day=itemView.findViewById(R.id.date);
        }
    }
}
