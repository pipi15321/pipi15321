package com.example.appomg.Model;

public class User2 {

    private String id;
    private String username;
    private String imageURL;
    private String status;
    private String search;
    private String email;
    private String phone_number;
    private String card;
    private String password;

    public User2(String id, String username, String imageURL, String status, String search) {
        this.id = id;
        this.username = username;
        this.imageURL = imageURL;
        this.status = status;
        this.search = search;
    }

    public User2() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }

    public String getEmail() {
        return email;
    }

    public void setEmailh(String email) {
        this.email = email;
    }

    public String getPhone_num() {
        return phone_number;
    }

    public void setPhone_num(String phone_num) {
        this.phone_number = phone_num;
    }
    public String getCard() {
        return card;
    }

    public void setCard(String card) {
        this.card = card;
    }

    public void setPassword(String password) {
        this.password = password;
    }  public String getPassword() {
        return password;
    }


}
