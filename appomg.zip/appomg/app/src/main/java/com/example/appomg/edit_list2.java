package com.example.appomg;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.Calendar;
import java.util.List;

import static com.example.appomg.ImageAdapter.user_key;

public class edit_list2 extends AppCompatActivity {
    private TextView name, price, place, day, imgurl2, uid,textView22,type_tv,remark,date, date2;
    private EditText edit_name, edit_price, edit_place, edit_day,type_et;
    private static final int REQUEST_CODE = 1;
    private ImageView imgurl;
    FirebaseAuth auth;
    Upload upload;
    private Button edit, delete, re;
    DatabaseReference ref, ref1;
    private List<Upload2> mUploads;
    private Context mContext;
    private FirebaseStorage mStorage;
    private ValueEventListener mDBListener;
    private int position;
    private Button finish,cancel_bt;
    private Spinner type,type_sp;
    private ImageButton time_bt, time_bt2;
    int year;
    int month;
    int dayOfMonth;
    Calendar calendar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_list2);
        cancel_bt=findViewById(R.id.cancel_bt);
        remark = findViewById(R.id.remark);
        type_sp= findViewById(R.id.type_sp);
        type_tv= findViewById(R.id.type_tv);
        type_et= findViewById(R.id.type_et);
        name = findViewById(R.id.name);
        delete = findViewById(R.id.delete);
        price = findViewById(R.id.price);
        place = findViewById(R.id.place);
        day = findViewById(R.id.day);
        imgurl = findViewById(R.id.imgurl);
        type = findViewById(R.id.type);
        auth = FirebaseAuth.getInstance();
        edit_name = findViewById(R.id.edit_name);
        edit_price = findViewById(R.id.edit_price);
        edit_place = findViewById(R.id.edit_place);
        edit_day = findViewById(R.id.edit_day);
        finish = findViewById(R.id.finish);
        textView22 = findViewById(R.id. textView22 );
        time_bt = findViewById(R.id.time_bt);
        time_bt2 = findViewById(R.id.time_bt2); //時間按鈕
        date = findViewById(R.id.date);
        date2 = findViewById(R.id.date2);
        upload=new Upload();
        final String Key = getIntent().getStringExtra(user_key);
        final DatabaseReference ref = FirebaseDatabase.getInstance().getReference("uploads_wish").child(Key);
        uid = findViewById(R.id.status);
        /*edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit_name.setEnabled(true);
                edit_place.setEnabled(true);
               edit_price.setEnabled(true);
                edit_day.setEnabled(true);

            }
        });*/
        time_bt.setOnClickListener(new View.OnClickListener() {  //
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(edit_list2.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {

                                date.setText(year + "-" + (month+1) + "-" + day);
                            }
                        }, 0, -1, 0);
                datePickerDialog.show();
            }
        });
        time_bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(edit_list2.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {


                                date2.setText(year + "-" + (month+1) + "-" + day);
                            }
                        }, 0, -1 ,0);
                datePickerDialog.show();
            }
        });
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (date.getText().toString() != "" && date2.getText().toString() != "") {

                    ref.child("imgName").setValue(edit_name.getText().toString());
                    ref.child("price").setValue(edit_price.getText().toString());
                    ref.child("place").setValue(type.getSelectedItem().toString());
                    ref.child("day").setValue(date.getText().toString() + "至" + date2.getText().toString());

                    ref.child("remark").setValue(remark.getText().toString());
                    ref.child("type").setValue(type_sp.getSelectedItem().toString());
                    edit_name.setEnabled(false);
                    edit_place.setEnabled(false);
                    edit_price.setEnabled(false);
                   day.setEnabled(false);
                   remark.setEnabled(false);
                    edit_place.setVisibility(View.VISIBLE);
                    type.setVisibility(View.INVISIBLE);
                    type_et.setVisibility(View.VISIBLE);
                    type_et.setEnabled(false);
                    type_sp.setVisibility(View.GONE);
                    findViewById(R.id.f).setVisibility(View.GONE);
                    findViewById(R.id.e).setVisibility(View.VISIBLE);
                } else {
                    Toast.makeText(edit_list2.this, "租用日期未填寫", Toast.LENGTH_SHORT).show();
                }
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ref.child("uid").setValue( textView22 .getText().toString());
                ref.child("status").setValue( textView22 .getText().toString());
                Toast.makeText(edit_list2.this, "刪除成功", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(edit_list2.this, publish2.class);
                startActivity(intent);

            }
        });
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Upload upload = dataSnapshot.getValue(Upload.class);

                Picasso.with(mContext)
                        .load(upload.getImgUrl())
                        .into(imgurl);
                name.setText("商品名稱:");
                edit_name.setText(upload.getImgName());
                place.setText("地區:");
                edit_place.setText(upload.getPlace());
                price.setText("價錢:");
                edit_price.setText(upload.getPrice());
                day.setText(upload.getDay());
                uid.setText(upload.getUid());
                type_et.setText(upload.getType());


            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        ref.removeEventListener(mDBListener);
    }


    public void re(View view) {
        Intent intent = new Intent();
        intent.setClass(edit_list2.this, publish2.class);
        startActivity(intent);
    }

    public void edit_list (View view) {
        edit_name.setEnabled(true);
        edit_place.setEnabled(true);
        edit_price.setEnabled(true);
        /* edit_day.setEnabled(true);*/
        remark.setEnabled(true);
        day.setEnabled(true);
        /*type_et.setEnabled(true);*/
        edit_place.setVisibility(View.GONE);
        type_et.setVisibility(View.GONE);
        type_sp.setVisibility(View.VISIBLE);
        type.setVisibility(View.VISIBLE);
        cancel_bt.setVisibility(View.VISIBLE);
        finish.setVisibility(View.VISIBLE);

        findViewById(R.id.f).setVisibility(View.VISIBLE);
        findViewById(R.id.e).setVisibility(View.GONE);

    }

    public void cancel(View view) {
        edit_name.setEnabled(false);
        edit_place.setEnabled(false);
        edit_price.setEnabled(false);
       /* edit_day.setEnabled(false);*/
        remark.setEnabled(false);
        day.setEnabled(false);


        edit_place.setVisibility(View.VISIBLE);
        type.setVisibility(View.INVISIBLE);
        type_et.setVisibility(View.VISIBLE);
        type_sp.setVisibility(View.INVISIBLE);
        cancel_bt.setVisibility(View.INVISIBLE);
        finish.setVisibility(View.INVISIBLE);
       findViewById(R.id.f).setVisibility(View.GONE);
        findViewById(R.id.e).setVisibility(View.VISIBLE);

    }



}