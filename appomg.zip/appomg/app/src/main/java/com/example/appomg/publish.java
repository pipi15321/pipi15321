package com.example.appomg;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.inputmethodservice.Keyboard;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import static com.example.appomg.ImageAdapter.user_key;

public class publish extends AppCompatActivity  implements  ImageAdapter_publish.OnItemClickListener {
    private static final String TAG = "Main2Activity";
    private ChildEventListener mchildListener;
    private ValueEventListener mDBListener;
    private RecyclerView mRecyclerView;
    private Button uidtext;
    private ProgressBar progressBar;
    private DatabaseReference mDatabaseRef;
    private List<Upload> mUploads;

    private ImageAdapter_publish mAdapter;
    private Context mContext;
    private FirebaseStorage mStorage;
    FirebaseRecyclerAdapter<Upload, RecyclerView.ViewHolder> adapter;
    private SearchView searchView;
    private ViewPager mViewPager;
    private String userUID;
    FirebaseAuth auth;
    private EditText edit;
    FirebaseAuth.AuthStateListener authListener;
    private int position;
    int counter = 0;
View view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publish);
        auth = FirebaseAuth.getInstance();
        progressBar = findViewById(R.id.progress_circular);
     /*   uidtext = findViewById(R.id.uidtext);*/
        mRecyclerView = findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        edit = findViewById(R.id.edit);
        mStorage = FirebaseStorage.getInstance();
        mUploads = new ArrayList<>();
      /*  Thread thread=new Thread(){
            @Override
            public void run(){
                super.run();
                for (int i=0;i<=100;){
                    if(i==100) {
                        progressBar.setVisibility(View.INVISIBLE);
                    }
                    try{
                        sleep(1000);
                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }progressBar.setProgress(i);
                    i=i+10;
                }
            }
        };
        thread.start();*/


        mDatabaseRef = FirebaseDatabase.getInstance().getReference("uploads");

        edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });


        mDBListener = mDatabaseRef.addValueEventListener(new ValueEventListener() {


            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                mUploads.clear();

                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Upload upload = postSnapshot.getValue(Upload.class);
                    upload.setKey(postSnapshot.getKey());
                    mUploads.add(upload);

                }
                mAdapter = new ImageAdapter_publish(publish.this, mUploads);
                mRecyclerView.setAdapter(mAdapter);
                mAdapter.setOnItemClickListener(publish.this);
                mAdapter.notifyDataSetChanged();

                progressBar.setVisibility(View.INVISIBLE);
            }
            /* progressBar.setVisibility(View.INVISIBLE);*/


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(publish.this, databaseError.getMessage(), Toast.LENGTH_LONG).show();
                progressBar.setVisibility(View.INVISIBLE);

            }
        });
       run(view);



    }

    @Override
    public void onItemClick(int position) {

        Toast.makeText(this, "Normal click at position: " + position, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onWhatEverClick(View view) {

        Toast.makeText(this, "Whatever click at position: " + position, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDeleteClick(int position) {
        Upload selectedItem = mUploads.get(position);
        final String selectedKey = selectedItem.getKey();
        StorageReference imageRef = mStorage.getReferenceFromUrl(selectedItem.getImgUrl());
        imageRef.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                mDatabaseRef.child(selectedKey).removeValue();
                Toast.makeText(publish.this, "Item deleted", Toast.LENGTH_SHORT).show();
                mUploads.clear();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mDatabaseRef.removeEventListener(mDBListener);
    }


    private void filter(String text) {
        ArrayList<Upload> myUploads = new ArrayList<>();
        for (Upload item : mUploads) {
            if (item.getImgName().toLowerCase().contains(text.toLowerCase())) {
                myUploads.add(item);
            }

        }
        mAdapter.filteredList(myUploads);
        mRecyclerView.setAdapter(mAdapter);
    }

    public void re(View view) {
        Intent intent = new Intent();
        intent.setClass(publish.this, ActivityTwo.class);
        startActivity(intent);
    }

  /*  public void uid(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("uploads").orderByChild("uid").equalTo(auth.getCurrentUser().getUid());
        query.addListenerForSingleValueEvent(mDBListener);
        progressBar.setVisibility(View.INVISIBLE);

    }*/

    public void run(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("uploads").orderByChild("uid").equalTo(auth.getCurrentUser().getUid());
        query.addListenerForSingleValueEvent(mDBListener);


    }
  public void run2(View view) {
      Query query1 = FirebaseDatabase.getInstance().getReference().child("uploads").orderByChild("status").equalTo("1");
      query1.addListenerForSingleValueEvent(mDBListener);
    }

}
