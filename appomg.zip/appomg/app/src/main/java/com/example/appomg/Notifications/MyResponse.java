package com.example.appomg.Notifications;

public class MyResponse {

    public int success;
}
