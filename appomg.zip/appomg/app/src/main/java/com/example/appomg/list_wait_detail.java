package com.example.appomg;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.squareup.picasso.Picasso;

import java.util.List;

import static com.example.appomg.ImageAdapter.user_key;

public class list_wait_detail extends AppCompatActivity implements ListwaitAdapter.OnItemClickListener{
    private TextView name, price, place, day, imgurl2, uid,time,uid2,host2,list_message,remark,username,host_name,double_price;
    private static final int REQUEST_CODE = 1;
    private ImageView imgurl;
    FirebaseAuth auth;
    Order order;
    private ImageButton edit, delete, re;
    DatabaseReference ref,ref1,ref2;
    private List<Order> mUploads;
    private Context mContext;
    private FirebaseStorage mStorage;
    private ValueEventListener mDBListener;
    private int position;
    private Button finish,confirm,cancel;
    private Spinner type;
    String a;
    String b;
    /*DatabaseReference imageURL;*/
    private ImageView user_image,user_image2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_wait_detail);
        confirm = findViewById(R.id.confirm);
        name=findViewById(R.id.name);
        price=findViewById(R.id.price);
        double_price=findViewById(R.id.double_price);
        place=findViewById(R.id.place);
        time=findViewById(R.id.time);
        imgurl=findViewById(R.id.imgurl);
        uid=findViewById(R.id.uid);
        host2=findViewById(R.id.host2);

        username=findViewById(R.id.username);
        host_name=findViewById(R.id.host_name);
        list_message=findViewById(R.id.list_message);
        cancel=findViewById(R.id.cancel);
     /*   type=findViewById(R.id.type);*/
        auth = FirebaseAuth.getInstance();
        uid2  =findViewById(R.id.uid2);
        user_image=findViewById(R.id.user_image);
        user_image2=findViewById(R.id.user_image2);
        a=host2.getText().toString();
        remark=findViewById(R.id.remark);
        final DatabaseReference ref1= FirebaseDatabase.getInstance().getReference("Users").child(host2.getText().toString());
        final String Key=getIntent().getStringExtra(user_key);
        final DatabaseReference ref= FirebaseDatabase.getInstance().getReference("order").child(Key);

       user_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.putExtra("host", host2.getText().toString());
                intent.setClass(list_wait_detail.this,test2.class);
                startActivity(intent);


            }
        });

        user_image2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.putExtra("host", uid.getText().toString());
                intent.setClass(list_wait_detail.this,test2.class);
                startActivity(intent);


            }
        });
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ref.child("borrower").setValue(host2.getText().toString());
                ref.child("renter").setValue(uid.getText().toString());
                ref.child("remark").setValue(remark.getText().toString());
                ref.child("status").setValue("3");
                ref.child("uid").removeValue();
                ref.child("host").removeValue();
                finish();
                Intent intent = new Intent();
                intent.setClass(list_wait_detail.this,list_ing.class);
                startActivity(intent);



            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              /*  ref.child("renter").setValue(uid.getText().toString());
                ref.child("borrower").setValue(host2.getText().toString());*/
                ref.child("uid").removeValue();
                ref.child("status").setValue("0");
                ref.child("host").removeValue();
                finish();

                Intent intent = new Intent();
                intent.setClass(list_wait_detail.this,list_wait.class);
                startActivity(intent);
            }
        });


        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Order order=dataSnapshot.getValue(Order.class);
                Picasso.with(mContext)
                        .load(order.getImgUrl())
                        .into(imgurl);
                name.setText("商品名稱:"+order.getName());
                place.setText("地區:"+order.getPlace());
                price.setText("價錢:$"+order.getPrice());
                double_price.setText("押金:$"+order.getDouble_price());
                time.setText("租用日期:" + order.getDay());
                remark.setText("備註:"+order.getRemark());
                uid.setText(order.getUid()); //刊登者
                uid2.setText(auth.getCurrentUser().getUid()); //抓現在進來的會員
                host2.setText(order.getHost()); //借用者
                username.setText(order.getUsername());
                host_name.setText(order.getHost_name());

                a=uid.getText().toString();
                b=uid2.getText().toString();
                if(a.equals(b)==false ){
                    findViewById(R.id.b).setVisibility(View.VISIBLE);
                    findViewById(R.id.c).setVisibility(View.GONE);
                    confirm.setVisibility(View.INVISIBLE);
                    list_message.setVisibility(View.VISIBLE);
                }else{
                    confirm.setVisibility(View.VISIBLE);

                    list_message.setVisibility(View.INVISIBLE);
                    findViewById(R.id.b).setVisibility(View.GONE);
                    findViewById(R.id.c).setVisibility(View.VISIBLE);
                }


            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    @Override
    public void onItemClick(int position) {

    }

    @Override
    public void onWhatEverClick(View view) {

    }

    @Override
    public void onDeleteClick(int position) {

    }
    public void re(View view) {
        Intent intent = new Intent();
        intent.setClass(list_wait_detail.this, list_wait.class);
        startActivity(intent);
    }

}
