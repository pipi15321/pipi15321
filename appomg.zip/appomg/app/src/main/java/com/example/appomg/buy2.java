package com.example.appomg;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.List;

public class buy2 extends AppCompatActivity {
    private TextView name, price, day, uid, place, state, type, date_end, remark, time, username, imageURL,host_name;
    private Button order_bt;
    private ImageView imgurl;
    FirebaseAuth auth;
    private List<Upload_wish> mUploads;
    private Context mContext;
    String a;
    Order order;
    private StorageReference mStorageRef;
    private DatabaseReference mDatabaseRef,ref2;
    private EditText double_price;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy2);

        uid = findViewById(R.id.uid);
        imgurl = findViewById(R.id.imgurl);
        price = findViewById(R.id.price);
        day = findViewById(R.id.day);
        type = findViewById(R.id.type);
        place = findViewById(R.id.place);
        state = findViewById(R.id.state);
        date_end = findViewById(R.id.date_end);
        order_bt = findViewById(R.id.order_bt);
        remark = findViewById(R.id.remark);
        time = findViewById(R.id.time);
        name = findViewById(R.id.name);
        username = findViewById(R.id.username);
        host_name = findViewById(R.id.host_name);
        imageURL = findViewById(R.id.imageURL);
        double_price = findViewById(R.id.double_price);
        auth = FirebaseAuth.getInstance();
        ref2 = FirebaseDatabase.getInstance().getReference().child("Users").child(auth.getCurrentUser().getUid());

        ref2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User user = dataSnapshot.getValue(User.class);
                host_name.setText(user.getUsername());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        String text1 = getIntent().getStringExtra("name");
        String text4 = getIntent().getStringExtra("uid");
        String text2 = getIntent().getStringExtra("price");
        String text3 = getIntent().getStringExtra("day");
        String url = getIntent().getStringExtra("imgurl2");
        String text5 = getIntent().getStringExtra("type");
        String text6 = getIntent().getStringExtra("state");
        String text7 = getIntent().getStringExtra("place");
        String text8 = getIntent().getStringExtra("date_end");
        String text9 = getIntent().getStringExtra("remark");
        String text10 = getIntent().getStringExtra("time");
        final String text11 = getIntent().getStringExtra("key");
        String text13 = getIntent().getStringExtra("username");
        String text14 = getIntent().getStringExtra("imageURL");
        Picasso.with(this).load(url).into(imgurl);
        a = url;

        name.setText(text1);
        price.setText(text2);
        day.setText(text3);
        uid.setText(text4);
        type.setText(text5);
        state.setText(text6);
        place.setText(text7);
        date_end.setText(text8);
        remark.setText(text9);
        time.setText(text10);
        username.setText(text13);
        imageURL.setText(text14);
        order = new Order();
        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("order_wish");
        auth = FirebaseAuth.getInstance();

        order_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!double_price.getText().toString().matches("")) {
                    new AlertDialog.Builder(buy2.this)
                            .setTitle("下單確認")
                            .setMessage("請確認填寫資訊是否正確，確認後請按下確定，完成下單程序。")
                            .setPositiveButton("確定",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            String orderID = mDatabaseRef.push().getKey();

                                            order.setUid(auth.getCurrentUser().getUid());
                                            order.setPrice(price.getText().toString());
                                            order.setPlace(place.getText().toString());
                                            order.setName(name.getText().toString());
                                            order.setDay(day.getText().toString());
                                            order.setType(type.getText().toString());
                                            order.setState(state.getText().toString());
                                            order.setHost(uid.getText().toString());
                                            order.setDate_end(date_end.getText().toString());
                                            order.setRemark(remark.getText().toString());
                                            order.setImgUrl(a);
                                            order.setTime(time.getText().toString());
                                            order.setUsername(host_name.getText().toString());
                                            order.setImageURL(imageURL.getText().toString());
                                            order.setDouble_price(double_price.getText().toString());
                                            order.setHost_name(username.getText().toString());
                                            mDatabaseRef.child(orderID).setValue(order);
                                            Toast.makeText(buy2.this, "下單成功", Toast.LENGTH_SHORT).show();
                                            Intent intent = new Intent(buy2.this, home2.class);
                                            startActivity(intent);
                                        }
                                    })
                            .setNeutralButton("取消", null)
                            .show();

                } else {
                    Toast.makeText(buy2.this, "押金未填寫", Toast.LENGTH_SHORT).show();
                }
            }

        });

    }
}