package com.example.appomg;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.List;

public class user_info extends AppCompatActivity {
    DatabaseReference ref,mDatabaseRef;
    FirebaseAuth auth;
    private TextView host/*username,*/;
    private Uri imgUrl;
    private StorageReference mStorageRef;
    FirebaseAuth.AuthStateListener authListener;
    User user;
   /* ImageView imgPreview;*/
    ImageButton re;
    private Context mContext;
    private ValueEventListener mDBListener;
    private List<Order> mUploads;
    private User_info_Adapter mAdapter;
    private RecyclerView mRecyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);
        /*imgPreview = findViewById(R.id.imgPreview);*/
        re = findViewById(R.id.re);
        auth = FirebaseAuth.getInstance();
        user = new User();
        String text4 = getIntent().getStringExtra("host");
        /*username = findViewById(R.id.username);*/
        host = findViewById(R.id.host);
        host.setText(text4);
        ref = FirebaseDatabase.getInstance().getReference().child("Users").child(host.getText().toString());
        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("order");
        mStorageRef = FirebaseStorage.getInstance().getReference("users");
        auth = FirebaseAuth.getInstance();
        mRecyclerView = findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        re.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

       /*ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                User user = dataSnapshot.getValue(User.class);
                Picasso.with(mContext)
                        .load(user.getImageURL())
                        .into(imgPreview);
                username.setText(user.getUsername());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });*/

        mDBListener =mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange (@NonNull DataSnapshot dataSnapshot){
                mUploads.clear();

                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Order order = postSnapshot.getValue(Order.class);
                    order.setKey(postSnapshot.getKey());
                    mUploads.add(order);
                }
                mAdapter = new User_info_Adapter(user_info.this, mUploads);
                mRecyclerView.setAdapter(mAdapter);
                mAdapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(user_info.this, databaseError.getMessage(), Toast.LENGTH_LONG).show();

            }


        });
    }

    }

