package com.example.appomg;

public class Response {
    private  String success;
}
