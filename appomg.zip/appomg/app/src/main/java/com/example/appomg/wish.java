package com.example.appomg;

import android.app.DatePickerDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.appomg.Model.User2;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.Calendar;

public class wish extends AppCompatActivity {
    private static final int CHOOSE_IMAGE = 1;
    FirebaseAuth auth;
    private Button chooseImage, btnUploadImage;
    private ImageButton time_bt,time_bt2;
    private ImageView imgPreview;
    private EditText imgName,price,remark;
    private ProgressBar uploadProgress;
    private Spinner place,type;
    private TextView date,date2,state,username,tdate,userimage;
    private Uri imgUrl;


    private StorageReference mStorageRef;
    private DatabaseReference mDatabaseRef,ref1,ref;
    User2 user;
    private StorageTask mUploadTask;
    int year ;
    int month ;
    int dayOfMonth;
    Calendar calendar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wish);

        uploadProgress = findViewById(R.id.uploadProgress);
        chooseImage = findViewById(R.id.chooseImage);
        btnUploadImage = findViewById(R.id.btnUploadImage);
        auth = FirebaseAuth.getInstance();
        type = findViewById(R.id.type);
        place = findViewById(R.id.place);
        price = findViewById(R.id.price);
        date = findViewById(R.id.date);
        date2 = findViewById(R.id.date2);
        time_bt2 = findViewById(R.id.time_bt2);
        auth = FirebaseAuth.getInstance();
        state = findViewById(R.id.state);
        imgName = findViewById(R.id.imgName);
        imgPreview = findViewById(R.id.imgPreview);
        remark = findViewById(R.id.remark);
        username = findViewById(R.id.username);
        userimage= findViewById(R.id.userimage);
        time_bt=findViewById(R.id.time_bt);
        tdate=findViewById(R.id.time);
        mStorageRef = FirebaseStorage.getInstance().getReference("uploads_wish");
        mDatabaseRef = FirebaseDatabase.getInstance().getReference("uploads_wish");

        Button button = (Button) findViewById(R.id.button);
        ref = FirebaseDatabase.getInstance().getReference().child("Users").child(auth.getCurrentUser().getUid());

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                User user = dataSnapshot.getValue(User.class);

                userimage.setText(user.getImageURL());

                username.setText(user.getUsername());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        Thread t = new Thread() {    //日期秒數
            @Override
            public void run() {
                try {
                    while (!isInterrupted()) {
                        Thread.sleep(1000);
                        runOnUiThread(new Runnable() {
                            @RequiresApi(api = Build.VERSION_CODES.N)
                            @Override
                            public void run() {
                                TextView tdate = (TextView) findViewById(R.id.time);
                                long date = System.currentTimeMillis();
                                SimpleDateFormat sdf = new SimpleDateFormat("yyyy - MM - dd");
                                String dateString = sdf.format(date);
                                tdate.setText(dateString);
                            }
                        });
                    }
                } catch (InterruptedException e) {
                }
            }
        };
        t.start();

        btnUploadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mUploadTask != null && mUploadTask.isInProgress()) {
                    Toast.makeText(wish.this, "Upload in progress", Toast.LENGTH_LONG).show();
                } else {
                    uploadImage();
                }
            }
        });


        chooseImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showFileChoose();
            }
        });

        time_bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(wish.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {

                                date.setText(year + "-" + (month+1) + "-" + day);
                            }
                        }, 0, -1, 0);
                datePickerDialog.show();
            }
        });
        time_bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(wish.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {

                                date2.setText(year + "-" + (month+1) + "-" + day);
                            }
                        }, 0, -1, 0);
                datePickerDialog.show();
            }
        });

    }



    private void showFileChoose() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, CHOOSE_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CHOOSE_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imgUrl = data.getData();

            Picasso.with(this).load(imgUrl).into(imgPreview);
        }

    }

    private String getFileExtension(Uri uri) {
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    private void uploadImage() {

        if (imgUrl != null && date.getText().toString() !="" && date2.getText().toString()!=""&& !imgName.getText().toString().matches("")&&!price.getText().toString().matches("")) {
            final StorageReference fileReference = mStorageRef.child(System.currentTimeMillis() + "." + getFileExtension(imgUrl));

            mUploadTask = fileReference.putFile(imgUrl)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    uploadProgress.setProgress(0);
                                }
                            }, 500);
                            fileReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    Upload_wish upload_wish = new Upload_wish(auth.getUid(),imgName.getText().toString().trim(), uri.toString(), uri.toString()
                                            ,type.getSelectedItem().toString(),place.getSelectedItem().toString(),price.getText().toString(),
                                            date.getText().toString(),date2.getText().toString(),tdate.getText().toString(),state.getText().toString(),remark.getText().toString(),
                                            username.getText().toString(),userimage.getText().toString());

                                    String uploadID = mDatabaseRef.push().getKey();
                                    mDatabaseRef.child(uploadID).setValue(upload_wish);
                                    Toast.makeText(wish.this, "上傳成功", Toast.LENGTH_LONG).show();
                                    imgPreview.setImageResource(R.drawable.imagepreview);
                                    imgName.setText("");
                                    price.setText("");
                                    date.setText("");
                                    date2.setText("");
                                    remark.setText("");
                                }
                            });


                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(wish.this, e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                            uploadProgress.setProgress((int) progress);
                        }
                    });
        }
        else{
            Toast.makeText(wish.this, "商品資訊尚未填寫完整", Toast.LENGTH_SHORT).show();
        }
    }


    public void refresh(View view) {
        finish();
        Intent intent = new Intent(wish.this, home.class);
        startActivity(intent);
    }
}
