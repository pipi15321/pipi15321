package com.example.appomg;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class home2 extends AppCompatActivity implements ImageAdapter2.OnItemClickListener{
    private static final String TAG = "Main2Activity";
    private ChildEventListener mchildListener;
    private ValueEventListener mDBListener;
    private RecyclerView mRecyclerView;
    View view;
    private ProgressBar progressBar;
    private DatabaseReference mDatabaseRef;
    private List<Upload_wish> mUploads;
    private ImageAdapter2 mAdapter;
    private Context mContext;
    private FirebaseStorage mStorage;
    FirebaseRecyclerAdapter<Upload_wish, RecyclerView.ViewHolder> adapter;
    private SearchView searchView;
    private ViewPager mViewPager;
    private String userUID;
    FirebaseAuth auth;
    private EditText edit;
    FirebaseAuth.AuthStateListener authListener;
    private int position;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home2);
        auth = FirebaseAuth.getInstance();
        mRecyclerView = findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        edit = findViewById(R.id.edit);
        progressBar = findViewById(R.id.progress_circular);
        mStorage = FirebaseStorage.getInstance();
        mUploads = new ArrayList<>();
        mDatabaseRef = FirebaseDatabase.getInstance().getReference("uploads_wish");
        FloatingActionButton fab = findViewById(R.id.fab);

        FloatingActionButton mFabBut = (FloatingActionButton) findViewById(R.id.fab);
        mFabBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(home2.this, fab_select.class);
                startActivity(intent);
            }
        });

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavView_Bar);
        BottomNavigationViewHelper.disableShiftMode(bottomNavigationView);
        Menu menu = bottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(0);
        menuItem.setChecked(true);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.ic_arrow:

                        break;

                    case R.id.ic_android:
                        Intent intent1 = new Intent(home2.this, ActivityOne.class);
                        startActivity(intent1);
                        break;

                    case R.id.ic_books:
                        Intent intent2 = new Intent(home2.this, Activitytwo2.class);
                        startActivity(intent2);
                        break;

                    case R.id.ic_center_focus:
                        Intent intent3 = new Intent(home2.this,post_user.class);
                        startActivity(intent3);
                        break;

                    case R.id.ic_backup:
                        Intent intent4 = new Intent(home2.this, QA.class);
                        startActivity(intent4);
                        break;
                }


                return false;
            }
        });


        edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });
        /*mDatabaseRef = FirebaseDatabase.getInstance().getReference("uploads");*/
        mDatabaseRef = FirebaseDatabase.getInstance().getReference("uploads_wish");
        mDBListener = mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mUploads.clear();

                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Upload_wish upload_wish = postSnapshot.getValue(Upload_wish.class);
                    upload_wish.setKey(postSnapshot.getKey());
                    mUploads.add(upload_wish);
                }
                mAdapter = new ImageAdapter2(home2.this, mUploads);
                mRecyclerView.setAdapter(mAdapter);
                mAdapter.setOnItemClickListener(home2.this);
                mAdapter.notifyDataSetChanged();
                progressBar.setVisibility(View.INVISIBLE);
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(home2.this, databaseError.getMessage(), Toast.LENGTH_LONG).show();
                progressBar.setVisibility(View.INVISIBLE);
            }
        });
       /* run2(view);*/



    }
    @Override
    public void onItemClick(int position) {

        Toast.makeText(this, "Normal click at position: " + position, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onWhatEverClick(View view) {

        Toast.makeText(this, "Whatever click at position: " + position, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDeleteClick(int position) {
        Upload_wish selectedItem = mUploads.get(position);
        final String selectedKey = selectedItem.getKey();
        StorageReference imageRef = mStorage.getReferenceFromUrl(selectedItem.getImgUrl());
        imageRef.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                mDatabaseRef.child(selectedKey).removeValue();
                Toast.makeText(home2.this, "Item deleted", Toast.LENGTH_SHORT).show();
                mUploads.clear();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mDatabaseRef.removeEventListener( mDBListener);
    }


    private void filter(String text) {
        ArrayList<Upload_wish>myUploads=new ArrayList<>();
        for(Upload_wish item:mUploads){
            if(item.getImgName().toLowerCase().contains(text.toLowerCase())){
                myUploads.add(item);
            }

        }
        mAdapter.filteredList(myUploads);
        mRecyclerView.setAdapter(mAdapter);
    }

/*@Override
 public void onClick(int position) {
        Upload selectedItem=mUploads.get(position);
        String selectrdKey=selectedItem.getUid();

        String uid = upload.getUid();
        Intent intent=new Intent(mContext,DetailActivity.class);
        intent.putExtra(user_key,uid);
        mContext.startActivity(intent);


    }*/




//Init and attach

//Call signOut(
       /* mSectionsPageAdapter = new SectionsPageAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        setupViewPager(mViewPager);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);


        tabLayout.getTabAt(0).setText("出租單");
        tabLayout.getTabAt(1).setText("借入單");*/





    public void logout (View view) {
        new AlertDialog.Builder(home2.this)
                .setTitle("登出")
                .setMessage("確定要登出?")
                .setPositiveButton("確定",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                auth.getInstance().signOut();
                                Intent intent = new Intent();
                                intent.setClass(home2.this, Main2Activity.class);
                                startActivity(intent);

                            }
                        })
                .setNeutralButton("取消", null)
                .show();



    }
   /* public void run2(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("uploads").orderByChild("state").equalTo("1");
        query.addListenerForSingleValueEvent(mDBListener);


    }*/
    /*  public void run1(View view) {
  String uid;
  uid=auth.getCurrentUser().getUid();
          Query query = FirebaseDatabase.getInstance().getReference().child("uploads").orderByChild("uid").equalTo(uid!=auth.getCurrentUser().getUid());
          query.addListenerForSingleValueEvent(mDBListener);


      }*/
    public void refresh(View view) {

        Intent intent = new Intent();
        intent.setClass(home2.this, home.class);
        startActivity(intent);

    }
    public void one(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("uploads_wish").orderByChild("type").equalTo("3C產品");
        query.addListenerForSingleValueEvent(mDBListener);
    }
    public void two(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("uploads_wish").orderByChild("type").equalTo("電器產品");
        query.addListenerForSingleValueEvent(mDBListener);
    }
    public void three(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("uploads_wish").orderByChild("type").equalTo("文具書籍");
        query.addListenerForSingleValueEvent(mDBListener);
    }
    public void four(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("uploads_wish").orderByChild("type").equalTo("居家生活");
        query.addListenerForSingleValueEvent(mDBListener);
    }
    public void five(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("uploads_wish").orderByChild("type").equalTo("衣服配飾");
        query.addListenerForSingleValueEvent(mDBListener);
    }
    public void six(View view) {
        Query query = FirebaseDatabase.getInstance().getReference().child("uploads_wish").orderByChild("type").equalTo("休閒娛樂");
        query.addListenerForSingleValueEvent(mDBListener);
    }
}